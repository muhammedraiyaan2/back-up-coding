#include <stdio.h>
int main()
{
    int a,b;
    printf("Enter the first number: ");
    scanf("%d", &a);
    printf("Enter the second number: ");
    scanf("%d", &b);
    printf("The sum of two numbers is %d",a+b);
}
