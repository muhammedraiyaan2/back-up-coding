void main(){
    var a="Masha Allah";
    for(var i=0; i<10; i++){
    print(a);
    }
}