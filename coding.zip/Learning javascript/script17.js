console.log("Today I have assemble")
setTimeout(() => {
    for(i=0; i<45; i++){
        let element=i
        console.log("This is index number "+i)
    } 
}, 100);

console.log("Done Printing")