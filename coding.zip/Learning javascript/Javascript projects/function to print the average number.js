//we wil create a function that will print the average number for two digit numbers
let avg=(a,b)=>{
return (a+b)/2
}