//prime number finder function
function primeNumber(ab){
    //I created a function name primeNumber and I will take a input from the user and print it is it prime number or not
    if(ab%1 && ab%ab){
        //here I check in the condinals that is this number is divisible by 1 and it is divisible by it self
        return "Prime Number"
    }
    else{
        return "Not Prime Number"
    }
}
console.log(primeNumber(5))