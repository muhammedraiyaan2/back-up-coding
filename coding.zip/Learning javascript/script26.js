console.log("Hi everybody regular expression")
// let reg=/^Raiyaan/i
// let reg=/[a-z]aiyaan/
//means it can be anything from a to z
// let reg = /[rR]aiyaan/
//means if r or R is there in first letter than send the result
// let reg = /[^j]aiyaan/
//means if the any charater example j don't have the starting letter like j
// let reg = /raiya{2}n/
 //means that a can come to 2 times
let reg=/raiya{0,2}n/
let str = "raiyaan bhai"
let result = reg.exec(str)

console.log("The result from the exec is ", result)
if (reg.test(str)) {
    console.log(`The string ${str} match's the ${reg.source}`)
}
else {
    console.log(`The string ${str} doesn't match's the ${reg.source}`)
}