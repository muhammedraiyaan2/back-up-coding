console.log("Hello I am learning the javascript")
function fruitsIt(values){
 let nameIndex=0
 return{
     next:function(){
         if(nameIndex<values.length){
           return  {
                 value:values[nameIndex++],
                 done:false
             }
         }
         else{
            return {
                 done:true
            }
         }
     }
 }
}
let fruit=[`apple`,`grapes`,`orange`,`pine apple`]
console.log("My favortite fruits are ",fruit)
let fruit2=fruitsIt(fruit)
console.log(fruit2.next().value)
console.log(fruit2.next().value)
console.log(fruit2.next().value)
console.log(fruit2.next().value)
// console.log(fruit2.next().value)
// console.log(`This will print all the value of the fruit`)
// fruit.forEach(out => {
//     console.log(out)
// });