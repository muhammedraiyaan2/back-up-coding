console.log("hello world")
alert("Check the console");
let car = {
    name: "Toyota",
    topSpeed: 189,
    run: function () {
        console.log("Car is running at ", topSpeed)
    }
}
function carfun(givenname, speed) {
    this.topSpeed = speed
    this.name = givenname
    this.run = function run() {
        console.log(`${this.name} this car is running at ${this.topSpeed}`)
    }
    this.analyze = function () {
        console.log(`This car is slower by ${200 - this.topSpeed} than Bmw`)
    }
}
let car1 = new carfun("Benz", 100)
console.log(car1)
console.log(car)