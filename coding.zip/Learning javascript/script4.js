//numebr to string
document.write("welcome to the tut4<br>")
let num=String(53)
//this is number I converter to string
document.write('the num variable datatype is a '+(typeof num)+"<br>")
//boolean to string
let a=String(true)
//this boolean a coverted into string
document.write("The a variable is "+(typeof a)+"<br>")
document.write("The date type is a "+(typeof new Date())+"<br>")
//another method for writing the string
let rt=56
document.write('The variable of rt type is a '+(typeof rt.toString())+"<br>")
//string to number
let ab=Number("96")
document.write("The variable bg is a "+(typeof bg)+"<br>")
//string to Integer
let abc=parseInt("-56.56 ")
document.write(abc+(typeof abc)+"<br>")
//string to float
let cba=parseFloat("563.67")
document.write(cba.toFixed(100)+(typeof cba)+"<br>")
//to fixed function is print the decimal number that we want in a range