console.log('Hello world')
let proto={
    slogan:function(){
        return "This company is the best"
    },
 changeName:function(newName){
this.name=newName
}
}
let raiyaan=Object.create(proto)
raiyaan.name="Muhammad Raiyaan"
raiyaan.job="Programmer"
raiyaan.changeName("Muhammad Raiyaan I")
console.log(raiyaan)