//variables in javascript
//there are 3 variable funtion let const var
var con='hi'
let co=5
const c=5.5
alert(con)
alert(co)
alert(c)