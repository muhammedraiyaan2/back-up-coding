console.log("Ehllwow adsjkfhajksfhjkhashbf kjashdfjhdkfh djksahfla")
let students = [
    { name: "Muhammad Raiyaan I", subject: "Java" },
    { name: "Muhammad Rafhaan I", subject: "Javascript" }
]
function enrollStudent(student,callback) {
    setTimeout(function () {
        students.push(student)
        callback()
    }, 3000)
}
function getStudents() {
    setTimeout(function () {
let string=""
students.forEach(function (studen){
    string +=`<li>${studen.name}</li>`
})
let aba=document.getElementById('students').innerHTML=string


    }, 1000)
}
let stu1={name:"Muhammad Raiyaan I Programemr", subject:"Java"}
enrollStudent(stu1, getStudents())
// getStudents()