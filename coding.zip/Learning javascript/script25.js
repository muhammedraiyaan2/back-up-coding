console.log("Yes you are there")
let reg = /Raiyaan/
let string = "Raiyaan is a good raiyaan and raiyaan is a good programmer"
let result = reg.exec(string)
reg=/^R/
reg=/an$/
reg=/Rai.aan/
console.log("The result from the exec is ", result)
if (reg.test(string)) {
    console.log(`The string ${string} match's the ${reg.source}`)
}
else {
    console.log(`The string ${string} doesn't match's the ${reg.source}`)
}