//Local storage
//local storage will store the data in the device 
// localStorage.setItem("Name","Muhammad Raiyaan I")
// let a=localStorage.getItem("Name")
// // let c=localStorage.removeItem("Name")
// //This will remove a particular item
// // let b=localStorage.clear()
// //this clear function will clear your local storage so that's why I comment out the code
// alert(a)
//session storage
//session storage will store the data on the website
let a1=sessionStorage.setItem("Name","Muhammad Raiyaan I")
let a2=sessionStorage.getItem("Name")
// let c=sessionStorage.removeItem("Name")
//This will remove a particular item
// let b=sessionStorage.clear()
//this clear function will clear your local storage so that's why I comment out the code
alert(a2)