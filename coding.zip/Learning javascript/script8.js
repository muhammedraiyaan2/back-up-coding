let a=document.getElementById('heading')
a.addEventListener("mouseover",function a(t){
    alert("You cliked on the heading")
    console.log(t.target)
})