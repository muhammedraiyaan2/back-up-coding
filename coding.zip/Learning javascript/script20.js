console.log("hello world")
function func1(){
    return new Promise(function(resovle,reject){
setTimeout(() => {
    const error=true
    if(!error){
    console.log("You promise is resloves")
    resovle()
    }
    else{
        console.log("You promise is rejected")
        reject()
    }
}, 2000);
    })
}
func1().then(function(){
    console.log("You function has been resloved sir")
}).catch(function(error){
    console.log("Cannot resolve " + error)
})