//strings
let a="Muhammad Raiyaan";
alert("My name is "+a);
alert("My datatype is "+(typeof a));
//this will print the type of a variable or a datatype
//number
let mark=98;
alert("My mark in my exam is "+mark)
alert("The datatype of my mark is "+(typeof mark))
//boolean
let b=true;
alert("I am programmer "+b)
alert("The datatype of the b variable is "+(typeof b))
//null or a object
let c=null
alert("This is a "+(typeof c))
//undefined
let d=undefined;
alert("The variable of d is "+(typeof d))
//array or a object
let e=[1,2,3,4,5,6,7,7,8,9]
alert("The e vairable type is "+(typeof e))
let f=[5,6,"hi my name is Muhammad Raiyaan"]
alert(f[2])
//In the array to print a array as alert(variable name[value]) in value you have yo give some value if 0 as m then 1 as k so on