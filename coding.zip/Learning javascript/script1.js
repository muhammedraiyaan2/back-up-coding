//console's
console.log('console log')
console.warn('Console warn')
//this is console log used for to warn anything
console.error('Console error')
//console error is a type of console error
console.table('')