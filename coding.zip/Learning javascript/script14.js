console.log("Welcome")
let a={
    name:"Muhammad Raiyaan",
    Work:"Programmer",
    Age:11
}
function Obj(givenName){
this.name=givenName
Obj.prototype.getName=function (){
    return this.name;
}
}
let obj2=new Obj("Muhammad Raiyaan")
console.log(obj2)