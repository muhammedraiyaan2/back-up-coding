console.log("dai I aam ")
let aa=(a,b)=>{//this is arrow function this is also a function
console.log(a+b)
}
aa(5,5)