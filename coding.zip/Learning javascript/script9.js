let a=document.getElementById('btn')
// a.addEventListener("click",fun)
// function fun(){
//     alert("You cliked on the button")
// }
// a.addEventListener("dblclick",doub)
// function doub(){
//     alert("You double click in the button")
// }
// a.addEventListener("mousedown",fun3)
// function fun3(){
//     alert("You mouse down click in the button")
// }
// a.addEventListener("mouseenter",fun4)
// function fun4(){
//     alert("You mouse enter click in the button")
// }
// a.addEventListener("mouseleave",fun5)
// function fun5(){
//     alert("You mouse leave in the button")
// }
let ab=document.getElementById('body')
ab.addEventListener("mousemove",fun6)
function fun6(t){
    document.body.style.background=`rgb(${t.offsetX},${t.offsetX},${t.offsetX+t.offsetY})`
}