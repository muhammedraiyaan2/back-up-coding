console.log("Hello world");
let map = new Map();
let key1 = "myString",
  key2 = {},
  key3 = function () {};
map.set(key1, `this is a string`);
map.set(key2, `this is a blank array`);
map.set(key3, `this is a blank function`);
console.log(map);
console.log(map.get(key1));
for (let [key, value] in map) {
  console.log(key + value);
}
for(let key of map.keys()){
    console.log(key);
}
