let aai=document.getElementById('container')
let b=document.createElement('h1')
//document.create element create a tag or a element
b.innerHTML="<b>This is javascript by script7.js</b>"
let c=innerText="I am javascript from script 7"
//there is like innerHtml there is innerText to aplly the text
b.setAttribute("title",'Javascript')
b.id="Java script id"
b.className="Javascript class"
aai.appendChild(b)
b.replaceWith(c) 
let e=document.getElementById('hello')
aai.removeChild(e)
console.log(aai.getAttribute)
console.log(b)