console.log("dai")
class empolyee{
    constructor(newname,newexperience,newdivision){
        this.name=newname
        this.experience=newexperience
        this.division=newdivision
    }
 slogan(){
     return `I am ${this.name} and this company is the best`
 }
 joiningyear(){
return 2021-this.experience
 }
 static add(a,b){
return a+b
 }
}
let ab=new empolyee("Muhammad Raiyaan",56,"Programmer")
console.log(ab.joiningyear())
console.log(empolyee.add(5,5))