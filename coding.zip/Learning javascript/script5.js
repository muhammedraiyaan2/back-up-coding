//functions in javascirpt
function goodmorn(name='name'){
    //when a function needs a value the user is not giving a value to him then it will print udenfined, So we can use this="the" then it will print the default value that the function tolled the user
    document.write(`Good morning ${name}`)
    //what is ${name}?
    //${name} is a variable stroge by the user for that you have to write this ` for Strating you don't write single or double codes

goodmorn("Muhammad Raiyaan<br>")
//array in a different method
let ab={
    name:"Muhammad Raiyaan I",
    age:11,
    school:"Sunbeam senior Cbse",
    work:"Programmer",
    class:7,
    keyboard:"live tech company",
    mouse:"lenovo",
    laptop:"Dell i5 3th gen 4gb ram 512gb storage"
}
document.write(ab.work)}
