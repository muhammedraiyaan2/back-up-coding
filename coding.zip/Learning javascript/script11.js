console.log("Welcome to maths object in javascript")
let x=3
let y=6
let z
z=x+y
z=x-y
z=x*y
z=x/y
z=Math
z=Math.PI
z=Math.E
z=Math.round(5.6)
z=Math.ceil(5.3)
z=Math.floor(-5.7)
z=Math.abs(-8)
z=Math.sqrt(56)
z=Math.min(5,2,5,3,88,44,78,85,10,11,133,45,78,1,9,4,6,67,45,32,21,12)
z=Math.max(5,2,5,3,88,44,78,85,10,11,13,45,78,1,9,4,6,67,45,32,21,12)
z=Math.random()
z=100*Math.random()//This random number prints with the decimal
z=Math.floor(Math.random()*10)//this print the random number with integers
console.log(z)