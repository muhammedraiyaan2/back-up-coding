console.log("dau")
async function fun(name){
    let res= await fetch("https://api.github.com/users")
    console.log(`before response`)
    let users= await res.json()
    return name+" is a programmer"
}
console.log("Before printing the fun function")
let ab=fun("Muhammad Raiyaan I")
console.log("After printing the fun function")
console.log(ab)
console.log("Finnally printed the function")
