let a=document.getElementById('this');
console.log(a)
a.style.color ='lightgreen'
a.style.fontSize='70px'
a.innerHTML='I am javascript'
a.querySelector='I'
console.warn("You are in danger you can be hacked.")