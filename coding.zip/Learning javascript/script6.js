let a=document.getElementById('this');
console.log(a)
a.style.color ='lightgreen'
a.style.fontSize='70px'
a.innerHTML='I am javascript'
a.querySelector('.class')
a.querySelector('div')
let abc=document.getElementsByTagName('div')
console.log(abc)
console.error("You are in danger you can be hacked.")
