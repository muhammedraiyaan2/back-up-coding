console.log("Hello world this is script 24 .js Today I created the code key contaienr very responsively")
let reg = `this is`
console.log(reg.source)
let rg = `this`
// console.log(reg.exec(rg))
// console.log(reg.test(rg))
// console.log(rg.indexOf("this"))
//this is a function
let matchIt =(varname,text)=>{
    let a=varname.indexOf(text)
    if(a>-1){
        return "true"
    }
    else{
        return "false";
    }
}
console.logmatchIt(reg,rg))