console.log("Hello world this is script 24 .js Today I created the code key contaienr very responsively")
let reg = `this is`
console.log(reg.source)
let rg = `this`
// console.log(reg.exec(rg))
// console.log(reg.test(rg))
// console.log(rg.indexOf("this"))
console.log(rg.replace("this","the"))
rg.replace("this","the")
console.log(rg)
