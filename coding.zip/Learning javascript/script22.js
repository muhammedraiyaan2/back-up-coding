console.log("Hello world Dai")
let fetch=document.getElementById('fetchBtn')
let your=document.getElementById('btnYour')
function getData(){
    console.log("Started getData")
    url = "text.txt";
    fetch(url).then((response)=>{
        console.log("Inside first then")
        return response.json();
    }).then((data)=>{
        console.log("Inside second then")
        console.log(data);
    })
}
getData()