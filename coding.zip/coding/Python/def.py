import random
import math
def avg(a):
    print (a/2)
def p(p):
    print(p)
def rand(a,b):
    return random.randint(a,b)
def add(a,b):
    print(a+b)
def sub(a,b):
    print(a-b)
sub(10982793457293045202134134999,10982793457293045202134134999)