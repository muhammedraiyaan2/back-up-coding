#We are creating a very simple AI with python
print("Welcome to the Simple AI")
#Here I print some message
print("AI: What's your name?")
name=input("You: ")
#here i asked the name from the user
print("AI: Where are you from?")
place=input("You: ")
#here I asked the place from the user
print("AI: What is your hobby?")
hobby=input("You: ")
#here I asked what is your hobby
print("Hello",name)
#here I print the name of the user
print("From",place)
#here I print the place of the user
print("Who like's",hobby)
#here I printed the hobby of the user


