import pywhatkit
pywhatkit.sendwhatmsg("+918098092961","Testing whatsaap python",21,25)