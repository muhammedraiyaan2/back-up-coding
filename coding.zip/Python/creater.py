print("Welcome to the creater")
inputs=input("Enter the path: ")
root=open(inputs,"x")