import random
#Here I import the random library
print(random.randint(1,99999999999999999))
#Here I print the value