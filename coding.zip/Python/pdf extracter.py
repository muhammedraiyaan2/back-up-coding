import PyPDF2
a = PyPDF2.PdfFileReader("pdf.pdf")
print("About ",a.documentInfo)
stras = ""
stras += a.getPage(1).extractText()
print(stras)