import sample2
sample2.a.a("s")