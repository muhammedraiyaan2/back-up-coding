import math
#Here I imported math library
inpu=input("Enter the string: ")
#Here I will take input from the user for the word
print(len(inpu))