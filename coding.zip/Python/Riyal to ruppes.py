print("Hi welcome to the riyal to ruppes converter")
#Here I printed some message
riyal=int(input("Enter the riyal: "))
print(riyal*19.49)
open("E:\ALIBABA_40_THIEVES")