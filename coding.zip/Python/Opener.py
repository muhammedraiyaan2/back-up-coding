import os
input1=input("Enter the path to open: ")
os.startfile(input1)