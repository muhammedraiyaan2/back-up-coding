import os
print("Welcome to lists")
inputs=input("Enter the path: ")
print(os.listdir(inputs))