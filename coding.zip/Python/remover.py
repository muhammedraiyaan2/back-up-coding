import os
print("Hi welcome to remover")
inputs=input("Enter the path where you have to remove the file: ")
os.remove(inputs)