print("Hi welcome to the Celius to farenheat coverter")
#Here I printed some message
C=int(input("Enter the the celius value: "))
#Here I will take input from the user of c value
print("The farenheat value:"(C*9/5)+32)
#And I finally added the formula and printed the value