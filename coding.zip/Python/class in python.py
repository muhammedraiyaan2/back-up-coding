class Empolyee:
    print("he")
a=Empolyee()
a1=Empolyee.name="Muhammad Raiyaaan"
a2=Empolyee.age=11
a3=Empolyee.language="Java"
print(Empolyee.name,"Loves",Empolyee.language,"Programming language")