from tkinter import *
root=Tk()
root.title("I don't know the title")
root.geometry("600x500")
f1=Frame(root,bg="blue")
f1.pack(side=LEFT)
l=Label(f1,text="Project")
l.pack()
root.mainloop()