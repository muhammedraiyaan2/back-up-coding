from tkinter import *
root=Tk()
root.geometry("600x500")
#size of the window
root.minsize(400,300)
#min width of the window
root.maxsize(600,500)
#max width of the window
text=Label(text="Hi I am Muhammad Raiyaan I the programmer")
text.pack()
root.mainloop()