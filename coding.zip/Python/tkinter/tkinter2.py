from tkinter import *
root=Tk()
root.geometry("700x600")
photo=PhotoImage(file="image1.jpg")
label=Label(image=photo)
label.pack()
root.mainloop()