from tkinter import *
root=Tk()
root.geometry("700x200")
root.title("About Muhammad Raiyaan I")
# sets the label of the window
body=Label(text="Muhammad Raiyaan I is a programmer who is very\n very happy to learn coding",bg="purple",fg="white",padx=63,pady=75,font=("italic",20,"bold"),borderwidth=10,relief=SUNKEN)
# body.pack(side=BOTTOM, anchor="se",fill=X)
# fill means spred the box to the window
#slide means align of the box like left right, bottom and top
#achor means the direction
body.pack(side=LEFT,fill=Y)
root.mainloop()