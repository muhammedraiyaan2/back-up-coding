class a:
    def a(ab):
        print(ab)
