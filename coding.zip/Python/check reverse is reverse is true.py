print("Hi Welcome")
input_=input("Enter the number or string: ")
if input_==input_[::-1]:
    print("It's a reverse number or string")
else:
    print("No it's not reversed number or string")