print("Hi welcome to the farenheat to celius coventer")
#Here I printed some message
ff=int(input("Enter the fareheat value: "))
#Here I will take input from the user of f value
print((ff-32)*5/9)
#And I finally added the formula and printed the value