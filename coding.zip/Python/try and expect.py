try:
   jsdhfkjhsdkjfhjfhdjshafjashfshafjhsdhfasjdkfasldkjfkajshdfshdhnashbasdfhsdhhfhfhghghghghghghghhg
except:
    print("You are having a error")
    print("I have solved that")