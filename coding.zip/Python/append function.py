list=[1,2,3,4]
list.append(5)
loop=0
while loop<len(list):
    print(list[loop])
    loop+=1