#here i print some message
print("Welcome to the calculator")
a=int(input("Enter the first number"))
b=int(input("Enter the second number"))
#here I take two input from the user and save the input a vairable int
print("The addition of the two numbers is",a+b)
print("the subraction of two number is",a-b)
print("the multipltion of two number is",a*b)
print("the division of two number is",a/b)
