var1="Muhammad Raiyaan"
var2=var1.__add__(" programmer")
print(var2)