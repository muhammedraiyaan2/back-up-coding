print("Testing the pycharm IDE")
input("Masha Allah")
def hi():
    print("Hi man")
hi()
print("Kaise ho raiyaan bhai")