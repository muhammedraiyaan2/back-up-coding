# Write a function to find the average of two numbers
import pyttsx3
def average(a,b):
    return (a+b)/2
print("average is",average(9,10))
# writing a funciton to find the maximum of two numbers
def maximum(a,b):
    if a < b:
        return a,"true"
    else:
        return b,"false"
print("maximum is",maximum(5,3))
def average(a,b):
    return (a+b)/2
print(average(9,10))
def speak(audio):
    engine = pyttsx3.init('sapi5')
    voices=engine.getProperty("voices")
    engine.setProperty("voice",voices[0].id)
    engine.say(audio)
    engine.runAndWait()
    print(audio)
speak("boAt")
