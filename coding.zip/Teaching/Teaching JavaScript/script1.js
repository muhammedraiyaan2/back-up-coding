// var, let, const
let a=5
console.log("Hello")
let head=document.getElementById('head')
let input=document.getElementById('input')
console.log(input.value)
head.innerHTML="<u>Js</u>"
// Local Storage
/*setItem function
getItem funtion
removeItem function
clear function*/
// localStorage.setItem('name',"Muhammad Raiyaan")
// localStorage.removeItem('name')

// small project
if(localStorage.getItem('name')===null) {
let pro=prompt('Enter your name')
localStorage.setItem('name',pro)
}
else{
    alert(localStorage.getItem('name'))
}
// Confirm project
// let con=confirm('Are you sure you want to delete')
// if(con==true) {
//     alert("Deleting")
// }
// else{
//     alert("Not deleting")
// }