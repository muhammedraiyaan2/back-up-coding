#import numpy library
import numpy as np
arr=np.array([1,2,3,4,5])
#Iterating Arrays.
for i in arr:
    print(i)
#2D array
arr2=np.array([[1,2,3,4,5],[6,7,8,9,10]])
# print(arr2)
#We can iterate 2D arrays also.
for i in arr2:
    print(i)
print(arr2[1][2])
#Numpy Array Join
arr3=np.array([1,2,3])
arr4=np.array([4,5,6])
arrj=np.concatenate([arr3,arr4])
print(arrj)
#Join two 2-D arrays along rows (axis=1):
arr3=np.array([[1,2],[3,4]])
arr4=np.array([[5,6],[7,8]])
arrj=np.concatenate((arr3,arr4),axis=0)
print("2d array:\n",arrj)
#NumPy Array Slicing
nakko=np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19])
print(nakko[1:5])
print(nakko[18:])
print(nakko[0:10:4])
print(nakko+3)
#Slice elements from index 4 to the end of the array:

#Slice elements with step value:

#Perform Arithmetic Operations on Array

#Calculate square and sqrt of array elements:
print(nakko*nakko)
s=np.sqrt(nakko)
print(s)