# Blog

It's a very simple blog and very nice step by step blog that you can use for education purpose.

[Open blog website](https://muhammedraiyaan2.github.io/blog)

# About us

If you want ot know about us then go to the website and there is section name about us in the header of the right side

# Contact us

If you want to contact us go to the website and go to the contact us section in header of the right side
