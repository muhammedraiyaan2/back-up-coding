const index=()=>{
    window.location.pathname="index.html"
}
const about=()=>{
    window.location.pathname="about.html"
}
function contact(){
    window.location.pathname="contact.html"
}