# TextUtils
This application will tell you how many letters, words and spaces are there in your text. You can get upper case and lower case of the text and you can copy the text.
- - -
***[Open TextUtils website](https://muhammedraiyaan2.github.io/TextUtils)***
# How to use TextUtils
First you have to enter the text and click on submit and you can get the count of the text
# Dark mode and light mode
If you want to enable dark mode click the button in the header of the right side. Default the theme is light if you want to change the dark to light mode then double click on the on/off button. Single click for dark mode double click for light mode
# Contact Us
If you want to contact us go to the textutils website and go to contact us in the header and there you can get the contact details
