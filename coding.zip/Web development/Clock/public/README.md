# Clock
This application is a digital clock that helps you to see the time, date and time with different backgrounds

[Open clock application](https://muhammedraiyaan2.github.io/Clock)
# How to use the clock
It's simple to use when ever you come to this website please reload the website for the correct time or press <kbd>ctrl</kbd>+<kbd>r</kbd>
![image](image.png)
# Contact us
If you want to contact us mail to muhammedraiyaan2@gmail.com or else you can open our github profile id=muhammedraiyaan [Click here to open github profile](https://github.com/muhammedraiyaan2)