let input = prompt("Enter anything")
// let input=document.getElementById('input')
// let submit=document.getElementById('submit')
//variables
let aboutIn = input.indexOf(6);
if (input == "github" || input == "Github") {
    window.open("https://www.github.com/muhammedraiyaan2")
}
else if (input == "github res" || input == "Github res") {
    window.open("https://github.com/muhammedraiyaan2?tab=repositories")
}
else if (input == "help bot" || input == "Help bot") {
    window.open("https://github.com/muhammedraiyaan2/Help-Bot")
}
else if (input == "server" || input == "Server") {
    window.open("https://github.com/muhammedraiyaan2/Server")
}
else if (input == "backup" || input == "Backup") {
    window.open("https://github.com/muhammedraiyaan2/back-up-coding")
}
else if (input == "code with harry" || input == "Code with harry") {
    window.open("https://www.youtube.com/results?search_query=codewithharry")
}
else if (input == "codewithharry" || input == "Codewithharry") {
    window.open("https://www.codewithharry.com")
}
else if (input == "live server" || input == "Live server") {
    window.open("https://127.0.0.1:5500")
}
else if (input == "ebeam" || input == "Ebeam") {
    window.open("https://ebeam.sunbeamschool.org/d2l/home/6660")
}
else if (input == "codekey" || input == "Codekey") {
    window.open("https://github.com/muhammedraiyaan2/codekey")
}
else if (input == "whatsapp" || input == "Whatsapp") {
    window.open("https://web.whatsapp.com")
}
else if (input == "lido" || input == "Lido") {
    window.open("https://student.lidolearning.com/dashboard")
}
else if (input == "d" || input == "D") {
    window.open("file://D:/")
}
else if (input == "c" || input == "C") {
    window.open("file://C:/")
}
else if (input == "e" || input == "E") {
    window.open("file://E:/")
}
else if (input == "java sheet" || input == "Java sheet") {
    window.open("https://www.codewithharry.com/blogpost/java-cheatsheet")
}
else if (input == "c sheet" || input == "C sheet") {
    window.open("https://www.codewithharry.com/blogpost/c-cheatsheet")
}
else if (input == "c++ sheet" || input == "C++ sheet") {
    window.open("https://www.codewithharry.com/blogpost/cpp-cheatsheet")
}
else if (input == "html sheet" || input == "Html sheet") {
    window.open("https://www.codewithharry.com/blogpost/html-cheatsheet")
}
else if (input == "css sheet" || input == "Css sheet") {
    window.open("https://www.codewithharry.com/blogpost/css-cheatsheet")
}
else if (input == "js sheet" || input == "Js sheet") {
    window.open("https://www.codewithharry.com/blogpost/javascript-cheatsheet")
}
else if (input == "python sheet" || input == "python sheet") {
    window.open("https://www.codewithharry.com/blogpost/python-cheatsheet")
}
else if (input == "flask sheet" || input == "Flask sheet") {
    window.open("https://www.codewithharry.com/blogpost/flask-cheatsheet")
}
else if (input == "django sheet" || input == "Django sheet") {
    window.open("https://www.codewithharry.com/blogpost/django-cheatsheet")
}
else if (input == "mysql sheet" || input == "Mysql sheet") {
    window.open("https://www.codewithharry.com/blogpost/mysql-cheatsheet")
}
else if (input == "php sheet" || input == "Php sheet") {
    window.open("https://www.codewithharry.com/blogpost/php-cheatsheet")
}
else if (input == "r bot" || input == "R bot") {
    window.open("http://r-bot.muhammadraiyaan.repl.co/")
}
else if (input == "r food" || input == "R food") {
    window.open("http://r-food.muhammadraiyaan.repl.co/")
}
else if (input == "bootstrap" || input == "Bootstrap") {
    window.open("http://www.getbootstrap.com")
}
else if (input == "tailwind" || input == "Tailwind") {
    window.open("https://tailwindcss.com/")
}
else if (input == "tailblocks" || input == "Tailblocks") {
    window.open("https://tailblocks.cc/")
}
else if (input == "codekey out" || input == "codekey out") {
    window.open("https://muhammedraiyaan2.github.io/codekey")
}
else if (input == "calculator" || input == "Calculator") {
    let a = parseInt(prompt("Enter the first number"))
    let b = parseInt(prompt("Enter the second number"))
    let choice = prompt("Enter the symbol multiply add divide subract")
    if (choice == "+") {
        alert(a + b)
    }
    else if (choice == "-") {
        alert(a - b)
    }
    else if (choice == "*") {
        alert(a * b)
    }
    else if (choice == "/") {
        alert(a / b)
    }
    else {
        alert("Sorry Muhammad Raiyaan Didn't get")
    }
}
else if (input == "google" || input == "Google") {
    window.open("https://google.com")
}
else if (input == "youtube" || input == "Youtube") {
    window.open("https://youtube.com")
}
else if (input == "random 6" || input == "Random 6") {
    let ran = Math.floor(Math.random() * 6)
    alert(ran)
}
else if (input == "mansoor codes" || input == "Mansoor codes") {
    window.open("https://www.youtube.com/results?search_query=mansoor+codes")
}
else if (input == "noor bhai" || input == "Noor bhai") {
    window.open("https://www.youtube.com/results?search_query=noor+bhai+commedy")
}
else if (input == "amazon" || input == "Amazon") {
    window.open("https://www.amazon.in")
}
else if (input == "amazon india" || input == "Amazon india") {
    window.open("https://www.amazon.in")
}
else if (input == "amazon us" || input == "Amazon us") {
    window.open("https://www.amazon.com")
}
else if (input == "amazon saudi" || input == "Amazon saudi") {
    window.open("https://www.amazon.sa")
}
else if (input == "repl" || input == "Repl") {
    window.open("https://www.replit.com")
}
else if (input == "repl java" || input == "Repl java") {
    window.open("https://replit.com/repls/folder/Java")
}
else if (input == "repl dart" || input == "Repl dart") {
    window.open("https://replit.com/repls/folder/Dart")
}
else if (input == "dart" || input == "Dart") {
    window.open("https://www.google.com/search?q=dart+&sxsrf=ALeKk02Ee2qLxLVoV9ecQYOscpaW4Yqa_w%3A1627311067985&ei=28v-YMK_O4SW4-EPqIK64Ak&oq=dart+&gs_lcp=Cgdnd3Mtd2l6EAMyBAgjECcyBAgjECcyBAgjECcyBAgAEEMyBAgAEEMyCAgAELEDEIMBMgcIABCxAxAKMggIABCxAxCDATICCAAyAggASgQIQRgAUPU7WPU7YIw_aABwAngAgAGjAYgBjgKSAQMwLjKYAQCgAQGqAQdnd3Mtd2l6wAEB&sclient=gws-wiz&ved=0ahUKEwiCmZWR_oDyAhUEyzgGHSiBDpwQ4dUDCA8&uact=5")
}
else if (input == "java" || input == "Java") {
    window.open("https://www.google.com/search?q=Java&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "c lang" || input == "C lang") {
    window.open("https://www.google.com/search?q=C&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "c++" || input == "C++") {
    window.open("https://www.google.com/search?q=c%2B%2B&sxsrf=ALeKk02BekhTt3cA9ozVugYnc-tTtrv1og%3A1627652764627&ei=nAIEYendJbLZz7sPq_mwgAU&oq=c%2B%2B&gs_lcp=Cgdnd3Mtd2l6EAMyBAgjECcyBAgjECcyBAgjECcyCggAEIAEEIcCEBQyCAgAEIAEELEDMgsIABCABBCxAxCDATIECAAQQzILCAAQgAQQsQMQgwEyBAguEEMyBAgAEEM6BwgjELADECc6CAgAELADEJECOg4IABCABBCxAxCDARCwAzoRCC4QsQMQgwEQxwEQowIQsAM6CAgAEIAEELADOgsIABCxAxCDARCwA0oECEEYAVCIL1jYMGDANWgBcAB4AIABrwGIAZgDkgEDMS4ymAEAoAEByAEKwAEB&sclient=gws-wiz&ved=0ahUKEwjpm-mG94ryAhWy7HMBHas8DFAQ4dUDCA8&uact=5")
}
else if (input == "python" || input == "Python") {
    window.open("https://www.google.com/search?q=Python&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "html" || input == "Html") {
    window.open("https://www.google.com/search?q=Html&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "css" || input == "Css") {
    window.open("https://www.google.com/search?q=Css&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "javascript" || input == "Javascript") {
    window.open("https://www.google.com/search?q=Javascript&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "php" || input == "Php") {
    window.open("https://www.google.com/search?q=Php&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "json" || input == "Json") {
    window.open("https://www.google.com/search?q=Json&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "django" || input == "Django") {
    window.open("https://www.google.com/search?q=Django&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "flask" || input == "Flask") {
    window.open("https://www.google.com/search?q=Flask&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "search" || input == "Search") {
    let a = prompt("Enter the word")
    window.open("https://www.google.com/search?q=" + a + "&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "spring boot" || input == "Spring boot") {
    window.open("https://www.google.com/search?q=Spring+boot&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "node js" || input == "Node js") {
    window.open("https://www.google.com/search?q=Node+js&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "c#" || input == "C#") {
    window.open("https://www.google.com/search?q=C+sharp&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
}
else if (input == "wikipedia" || input == "Wikipedia") {
    let prom = prompt("Enter the word to search in wikipedia")
    window.open("https://en.wikipedia.org/wiki/" + prom)
}
else if (input == "open" || input == "Open") {
    let prom2 = prompt("Enter the link to open")
    window.open("https://" + prom2)
}
else if (input == "exit" || input == "Exit") {
    if (1 == 3) {
        alert("yes")
    }
}
else if (input == "readme" || input == "Readme") {
    window.open("https://www.readme.so")
}
else if (input == "compressor" || input == "Compressor") {
    window.open("https://compressjpeg.com/")
}
else if (input == "dawood" || input == "Dawood") {
    window.open("https://www.youtube.com/results?search_query=dawoodsavage")
}
else if (input == "google fonts" || input == "Google fonts") {
    window.open("https://fonts.google.com")
}
else if (input == "google meet" || input == "Google meet") {
    window.open("https://meet.google.com")
}
else if (input == "google chat" || input == "Google chat") {
    window.open("https://chat.google.com")
}
else if (input == "google keep" || input == "Google keep") {
    window.open("https://keep.google.com")
}
else if (input == "google word" || input == "Google word") {
    window.open("https://docs.google.com")
}
else if (input == "google excel" || input == "Google excel") {
    window.open("https://docs.google.com/spreadsheets/u/0/")
}
else if (input == "google excel" || input == "Google excel") {
    window.open("https://docs.google.com/spreadsheets/u/0/")
}
else if (input == "google power point" || input == "Google power point") {
    window.open("https://docs.google.com/presentation/u/0/")
}
else if (input == "google drive" || input == "Google drive") {
    window.open("https://drive.google.com")
}
else if (input == "google photo" || input == "Google photo") {
    window.open("https://photo.google.com")
}
else if (input == "google contact" || input == "Google contact") {
    window.open("https://contacts.google.com/")
}
else if (input == "gmail" || input == "gmail") {
    window.open("https://mail.google.com/")
}
else if (input == "google calendar" || input == "Google calendar") {
    window.open("https://calendar.google.com/")
}
else if (input == "google translate" || input == "Google translate") {
    window.open("https://translate.google.com/")
}
else if (input == "google hangouts" || input == "Google hangouts") {
    window.open("https://hangouts.google.com/")
}
else if (input == "google duo" || input == "Google duo") {
    window.open("https://duo.google.com/?usp=duo_ald")
}
// else if (input == "about" && aboutIn== || input == "C#") {
//     window.open("https://www.google.com/search?q=about"+aboutIn+"&sxsrf=ALeKk00Mc8L8Ebno00sEmAehUQkiK0rGfg%3A1627311123480&ei=E8z-YLvFHOWT4-EPmfK14A0&oq=Java&gs_lcp=Cgdnd3Mtd2l6EAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsAMyBwgAEEcQsANKBAhBGABQkwNYkwNgugRoAHADeACAAV6IAV6SAQExmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=gws-wiz&ved=0ahUKEwj7mtCr_oDyAhXlyTgGHRl5DdwQ4dUDCA8&uact=5")
// }
// else {
//     alert("Don't get Muhammad Raiyaan sir")
// }
    // else if (input != "github" && input != "github" && input == "whatsapp" && input == "Whatsapp" && input == "server" && input == "Server" && input == "backup" && input == "Backup" && input == "code with harry" && input == "Code with harry" && input == "codewithharry" && input == "Codewithharry" && input == "ebeam" && input == "Ebeam" && input == "codekey" && input == "Codekey" && input == "whatsapp" && input == "Whatsapp" && input == "lido" && input == "Lido" && input == "d" && input == "D" && input == "java sheet" && input == "Java sheet" && input == "c sheet" && input == "C sheet" && input == "c++ sheet" && input == "C++ sheet") {
    //     alert("Didn't get sir")
    // }
