// console.log("Hello world");
// (function(exports, require,module,__filename,__dirname){
let laptop = {
    name: "ASUS VivoBook 14",
    company: "ASUS",
    cpu: "Core i5 11th gen",
    ram: "16gb ram",
    storage: "512gb",
    disk: "SSD",
    graphic_card: "2gb nvidia graphic card"
};
console.log(exports, require,module,__filename,__dirname);
module.exports = laptop;
// })