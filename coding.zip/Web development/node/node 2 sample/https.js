let http = require('http');
let server=http.createServer((req, res) => {
    res.end("This is a default page of a server")
})
server.listen(1234,"127.0.0.1");