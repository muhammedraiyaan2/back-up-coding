let req = require("./second")
// console.log(req)
// os
let os = require("os")
console.log(os.type());
// path
let path = require("path")
console.log(path.basename("C:\\temp\\myfile.html"));
console.log(path.dirname("C:\\temp\\myfile.html"));
console.log(path.extname(__filename))
if (path.extname(__filename) == ".js") {
    console.log("This is a JavaScript file");
}
// file handling
let fs = require("fs")
fs.readFile("file.txt", "utf8", (err, data) => {
    console.log(data);
})
let a = fs.readFileSync("file.txt")
console.log(a.toString());
fs.writeFile('file2.txt','This file is written with NodeJs',()=>{
    if(false){
        console.log('s')
    }
})