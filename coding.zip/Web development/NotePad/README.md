# NotePad
If you want to use notepad but notepad is not installed in your PC or your ram is very less then you can use this site in google chorme or in another web browsesr.

[Open NotePad Site](https://muhammedraiyaan2.github.io/NotePad)
# Contact us and About us
If you want to know about us and contact us then [Click this link](https://muhammedraiyaan2.github.io/Profile)