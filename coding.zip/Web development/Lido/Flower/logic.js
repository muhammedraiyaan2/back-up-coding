function setup() {
    createCanvas(400,400);
}
function draw() {
    background(`lightgreen`);
    // circle 1
    fill(`aqua`)
    circle(100,140,120)
    // circle 2
    fill(`aqua`)
    circle(230,140,120)
    // circle 3
    fill(`aqua`)
    circle(100,270,120)
    // circle 4
    fill(`aqua`)
    circle(230,270,120)
    // center
    fill(`coral`)
    circle(170,200,130)
    strokeWeight(10)
    line(165,400,165,264)
}