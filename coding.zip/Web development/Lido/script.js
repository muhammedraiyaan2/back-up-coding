function setup() {
    createCanvas(400,400);
}
function draw() {
    background(255);
    //line number 1
    line(400,400,mouseX,mouseY)
    //line number 2
    line(0,0,mouseX,mouseY)
    //line number 3
    line(400,0,mouseX,mouseY)
    //line number 4
    line(0,400,mouseX,mouseY)
    // circle
    fill(mouseX,mouseY,mouseX-mouseY)
    circle(mouseX,mouseY,50)
} 