# HTML CheatSheet
This HTML CheatSheet will help you to copy the code and paste in your IDE. We have written all the necessary tags for HTML code. There will a copy button when you hover on the code.

[Open HTML CheatSheet Site](https://muhammedraiyaan2.github.io/HTML-CheatSheet/)
# About us and Contact us
Go to [this website for contact and about us](https://muhammedraiyaan2.github.io/Profile/)