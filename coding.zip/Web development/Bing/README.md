# Bing
This is a fake bing. This website request offical bing website
# Disclaimer
Please this is for a fun project don't take it serious