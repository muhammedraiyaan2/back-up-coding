# News Fetch
this application will help you to see your news daily. there is many section like health and science etc. With latest news. With best news company like bbc news and times of india etc.

[Open news fetch website](https://muhammedraiyaan2.github.io/News-fetch)
# Contact us
If you want to contact us then mail on muhammedraiyaan2@gmail.com or contact on github 
[github profile](https://github.com/muhammedraiyaan2)