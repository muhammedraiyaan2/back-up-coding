# Data Save
This application will help you to store lots of text like user id or password and name etc. But the application can't store videos, audios and images. Only text can be saved

[Open Data Save](https://muhammedraiyaan2.github.io/Data-Save)
# Dark mode and light mode
If you want to enable dark mode click the button in the header of the right side. Default the theme is light if you want to change the dark to light mode then double click on the on/off button. Single click for dark mode double click for light mode
# Data Save application is safe?
The data save application is safe because on you data is saved in your local storage so no don't worry
# How to use Data Save application
First you have to enter the name of the variable like name or suer id and in the second box you have to enter the value example: First box:user id and second box: user2589. If you want to add a variable then in the first input form you have to enter the variable name and in the second input form you have to enter the value of the variable and there is a post button click on it and the variable is saved in the website savely. If you want to get the variable value then go the middle of the website in the 4 input form and there you have enter the variable and click on the get button and you can get the variable name if the vairable is not there it will show null. If you want to remove a variable then go to the bottom and there is a input form there enter the variable name and click on the remove button and then you can remove the variable.If you want to remove all then go to the bottom there is a option like remove all click on it and it will ask you are sure and click on ok.
![image](Data%20Save.png)
# Contact
If you want to contact us go to the website and go to the contact us section in header of the right side and there you can get the contact details