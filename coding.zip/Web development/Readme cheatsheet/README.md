# Readme Cheatsheet
This Readme cheatsheet will help you to copy the code and paste and your readme.md file

***[Open Readme cheatsheet](https://muhammedraiyaan2.github.io/Readme-Cheatsheet)***
# What is Readme file?
Readme file is file that tells the user that what the website is going to do and how to use the website? 
