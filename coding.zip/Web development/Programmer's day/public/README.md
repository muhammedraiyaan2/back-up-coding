# Programmer's Day
In this website we have told about programmer's day and the quiz for programmers is there and there is 4 projects you can do anyone 

[Open Programmer's day website](https://muhammedraiyaan2.github.io/programmers-day)
# Quiz
There is a quiz for you to attend to test your skills all the quiz are single choice questions after you select all your option click on submit it will show you the mark 
# Project
There is 4 projects you can do anyone there is advance, medium and basic projects are there you can do anyone. I have written that what the project will do for you. If the project is finished then send the project on muhammedraiyaan2@gmail.com
# Contact us
If you want to contact us in the bottom of the website I have given the mail there you can contact. if you want to more details go to this [link](https://muhammedraiyaan2.github.io/Notes-taking-app/contact.html)