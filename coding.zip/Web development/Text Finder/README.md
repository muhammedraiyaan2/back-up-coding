# Text Finder
This application helps you to find a word in big paragraph for example word=this and paragraph=is this is a programmer?. It also tells you the index number.

**[Open Text finder](https://muhammedraiyaan2.github.io/Text-Finder)**
# How to use Text Finder application
First you have to enter the word in the first input and you have enter the paragraph in the second input and click on the submit button and you can get the information of your text
# Dark mode and light mode
If you want to enable dark mode click the button in the header of the right side. Default the theme is light if you want to change the dark to light mode then double click on the on/off button. Single click for dark mode double click for light mode
# Contact Us
If you want to contact us go to the Text Finder website and go to contact us in the header and there you can get the contact details
