let dark=document.getElementById('dark')
let body=document.getElementById('body')
let nav=document.getElementById('nav')
let send=document.getElementById('send')
let link_in=document.getElementById('link')
let name_in=document.getElementById('name')
let output=document.getElementById('output')
nav.style.background="#f8f9fa"
nav.style.color="#212529"
dark.addEventListener("click",function(){
    body.style.backgroundColor="#212529"
    body.style.color="#f8f9fa"
    nav.style.backgroundColor="#1c1c1c"
})
dark.addEventListener("dblclick",function(){
    body.style.color="#212529"
    body.style.backgroundColor="#fff"
    nav.style.backgroundColor="#f8f9fa"
})
send.addEventListener("click",function(){
output.innerText=`${name_in.value} Website Name
${link_in.value} Website Link`
})