let btn=document.getElementById('btn')
let text=document.getElementById('text')
let head=document.getElementById('head')
let body=document.getElementById('body')
btn.addEventListener("click",function(){
 function create(){
  let create=document.createElement('div')
  create.classList.add('jumbotron')
  create.innerText='sd'
  create.append(body)
  let create_txt=document.createElement('h1')
  create_txt.innerText="s"
  create.append(create_txt)
 }
 create()
})