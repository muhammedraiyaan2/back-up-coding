# Notes taking app
This application is a very awesome notes app which will help to finish your work at time

[Open notes taking app](https://muhammedraiyaan2.github.io/Notes-taking-app)
# How to use the application
It's simple to use first you have to enter the title of the note and the body of the note after the you have to click on submit it save your note on local storage and the data is save on you computer and if you want to delete a note and click on the delete option in the note of the bottom
# Contact
If you want to contact us go to the website and there in the right side of the header there is a section contact and there you can get the contact details