#include <stdio.h>

int main() {
   printf("Masha Allah \n");
   printf("Hello world");
   int a;
   char c[] = "c string";
   scanf("%d", &a);
   printf("%d",a);
   printf("\n%c",c);
}z