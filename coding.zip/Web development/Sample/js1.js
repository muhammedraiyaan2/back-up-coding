const name=require("./js2")
alert(name)
