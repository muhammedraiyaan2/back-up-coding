let a=document.getElementById('the')
a.addEventListener("click",function g(){
    let b=new XMLHttpRequest()
b.open("GET","ttspa2.html",true)
b.onload=function(){
    document.write(this.responseText)
}
b.onprogress=function(){
    document.write(this.responseText)
}
b.send()
})


