
# Github Copliot
Github Copliot is a AI program that will help you to program very quickly 
| postive feedback | 30%|
| ------- | --- |
| negative feedback | 70% |
--- 
[comment]:<--- sybmol is hr line>
