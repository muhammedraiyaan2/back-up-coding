# Snake Game
This is a simple snake game created with using only Html Css and Javascript. This game is very simple and fun. This game helps programmer a lot because when a programmer got stuck in a error then he or she would be frustrated and want some rest then this game helps a lot.

[Open snake game](https://muhammedraiyaan2.github.io/snake-game)
# How to play the game?
First press up arrow and start the game and you can see the score and high score in top right side and if you are out then it will show you a pop window that shows (game over press enter to continue or press ok) like that.
# About founder and Contact us on
If you want to know about the founder or if you want to contact us then go to this [Link](https://muhammedraiyaan2.github.io/Profile/)