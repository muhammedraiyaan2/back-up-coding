let link=document.getElementById('link').value
let btn=document.getElementById('btn')
btn.addEventListener("click",function(){
    // let xml=new XMLHttpRequest()
    // xml.open("GET",`https://${link}`,true)
    // xml.onload=function(){
    //     document.write(this.responseText)
    // }
    // xml.send()
    document.location=link
})