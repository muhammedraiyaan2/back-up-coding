let dark=document.getElementById('dark')
let body=document.getElementById('body')
let nav=document.getElementById('nav')
let input=document.getElementById('input')
let submit=document.getElementById('submit')
let output=document.getElementById('output')
nav.style.background="#f8f9fa"
nav.style.color="#212529"
submit.addEventListener(`click`,function(){
    let random=Math.floor(Math.random()*3+1)
    let ComS=0
    let UserS=0
if(random==1){
    alert(`Computer: Rock`)
}
if(random==2){
    alert(`Computer: Paper`)
}
if(random==3){
    alert(`Computer: Sccisor`)
}
//this is new conditonal
    if(input.value=="rock" && random==3 || input.value=="paper" && random==1 || input.value==`sccisor` && random==2){
     UserS+=1
    }
    else if(input.value=="paper" && random==3 || input.value=="sccisor" && random==1 || input.value==`rock` && random==2){
        ComS+=1
       }
    else{
        if(false){
            alert("false")
        }
    }
   if(UserS==5){
       alert("You have win")
   }
   if(ComS==5){
    alert("Computer have win")
}
if(ComS==5 && UserS==5){
    alert("Draw")
}
alert(`${ComS} computer and ${UserS} USer`)
})
dark.addEventListener("click",function(){
    body.style.backgroundColor="#212529"
    body.style.color="#f8f9fa"
    nav.style.backgroundColor="#1c1c1c"
})
dark.addEventListener("dblclick",function(){
    body.style.color="#212529"
    body.style.backgroundColor="#fff"
    nav.style.backgroundColor="#f8f9fa"
    nav.style.color="white"
})