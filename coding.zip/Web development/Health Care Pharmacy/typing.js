let i = 0;
let txt = 'Welcome to the Health Care Pharmacy you can get all your medicine here';
let speed = 60;
function typeWriter() {
  if (i < txt.length) {
    document.getElementById("demo").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}
