import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
export default function PythonBlogList() {
    document.title = `Blog - Python BlogList`
    return (
        <>
            <h1 className="heading2 text-center"><Link to="/5-python-projects-blog11">5 Python Projects <div className="badge">New</div> <button
                className="btn btn-outline-danger">Read more <i className="fal fa-info-circle"></i></button></Link> </h1> <br />
            <hr/>
            <h1 className="heading2 text-center"><Link to="/how-to-make-a-http-server-blog4">How to make a http server for web development with python<button
                className="btn btn-outline-danger">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            <h1 className="heading2 text-center"><Link to="/how-to-convert-py-file-to-exe-file">How to convert .py file to .exe file <button
                className="btn btn-outline-danger">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            <h1 className="heading2 text-center"><Link to="/pip-is-not-recognized-blog2">How to solve pip is not recognized as the internal or the
                external command error in python <button className="btn btn-outline-danger">Read more <i
                    className="fal fa-info-circle"></i></button></Link></h1>
            <br /><hr/>
            <br /><br /><br /><br /><br />
            <br /><br /><br /><br /><br />
        </>
    )
}
