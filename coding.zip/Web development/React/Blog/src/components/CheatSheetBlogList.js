import React from 'react'
import "./style.css"
import {
      BrowserRouter as Router,
      Switch,
      Route,
      Link
    } from "react-router-dom";
export default function CheatSheetBlogList() {
    document.title = `Blog - CheatSheet BlogList`
    return (
        <>
      <h1 className="heading2 text-center"><Link to="/HTML-cheatsheet-blog23">HTML CheatSheet <div className="badge">New</div>
      <button className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <br /><br />
  <br /><br />
  <br /><br />
  <br /><br />
  <br /><br />
  <br />
        </>
    )
}
