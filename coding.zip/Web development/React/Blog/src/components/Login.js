import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
export default function Login() {
    let log = document.getElementById('log')
    setTimeout(() => {
        document.title = 'Blog - Login'
    }, 1);
    const databasess = async () => {
        let na=document.getElementById('Name').value
        let Emails = document.getElementById('Email').value
        let Ages=document.getElementById('Age').value;
        let js={
            Name:na,
            Email:Emails,
            phoneNumber:Ages
        }
        await fetch("https://blog-c7e27-default-rtdb.firebaseio.com/Login.json",
        {
            method:"POST",
            body: JSON.stringify(js)
        })
    }
    function ll(){
        if(localStorage.getItem("Name") != ""){
            alert("Already Logined")
        }
    }
    setTimeout(() => {
        ll()
    }, 1);
    const login=()=>{
        if (localStorage.getItem("Name") == null) {
            let name = document.getElementById("Name").value;
            localStorage.setItem("Name", name)
        }
        else if (localStorage.getItem("Name") == "") {
            let name = document.getElementById("Name").value;
            localStorage.setItem("Name", name)
        }
        else if (localStorage.getItem("Name") != null) {
        let l= document.getElementById("l")
            l.click()
        }
        else if (localStorage.getItem("Name") != "") {
        let l= document.getElementById("l")
            l.click()
        }
        databasess()
    }
    if (localStorage.getItem("Name") == null) {
        localStorage.setItem("Name", "")
    }
    // setTimeout(() => {
    //     alerts.style.display = "none"
    // }, 10);
    return (
        <>
        <div className="mx-5">
        <label htmlFor="Name">Name</label><br/><br/>
        <input type="text" className="form-control" name="Name" id="Name" placeholder="Enter your name" required/><br/>
        <input type="Email" className="form-control" name="Email" id="Email" placeholder="Enter your Email" required/><br/>
        <input type="number" className="form-control" name="Age" id="Age" placeholder="Enter your phone number" required/>
        <br/><button onClick={login} id="log" className="btn btn-outline-primary">Login</button>
        <br/><br/>
        <div style={{display:"none"}} className="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success</strong> Successfully logged in.
            <button type="button" className="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <Link id="l" to="/"></Link>
        </div>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        </>
    )
}
