import React from 'react'
import "./footer.css"
import "./navbar.css"
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
export default function Footer() {
    let footer1={
        height:"50px",
        display: "inline-block",
        width:"50px"
    }
    return (
        <><br/><br/>
  <footer>
    <Link to="/"><img src="https://theblog.co.in/icon.png" alt="logo" class="logo"/></Link>
    <h1 class="footer-heading">Copyright &copy; 2022 theblog.co.in</h1>
    <h1 class="mail">Contact on support@theblog.co.in</h1>
</footer>
        </>
    )
}
