import React from 'react'
import './style.css'
export default function About() {
    document.title = `Blog - About`
    return (
        <>
        <div className="aboutDiv"><br />
<h1 class="about text-center" style={{color: 'green'}}>About Blog</h1>
  <h1 class="description text-center">This blog is created by Muhammad Raiyaan Who is 11 years old and he is Web
    developer and software developer. This blog website is planned by him and the blog is published by him</h1>
        <br /></div>
        <br/><br/><br/>    <br/><br/><br/>    <br/><br/><br/>    <br/><br/>
        <br/><br/><br/>    
        </>
    )
}
