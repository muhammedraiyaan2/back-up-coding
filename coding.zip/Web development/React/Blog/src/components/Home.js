import './style.css'
import React from 'react'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
// import './script'
// import './bootstrap.css';
// import "https://pro.fontawesome.com/releases/v5.10.0/css/all.css";
export default function Home() {
  document.title = `Blog`
  let home1 = {
    display: "block"
  }
  let home2 = {
    marginTop: "-70px",
    fontSize: "30px"
  }
  let home3 = {
    marginTop: "-10px"
  }
  let home4 = {
    fontSize: "24px",
    marginLeft: "9px"
  }
  function logout(e) {
    if (localStorage.getItem("Name") != null) {
      localStorage.removeItem('Name')
    }
    if (localStorage.getItem("Name") == null) {
      localStorage.setItem("Name", "")
    }
  }
  if (localStorage.getItem("Name") == null) {
    localStorage.setItem("Name", "")
  }
  else if (localStorage.getItem("Name") == `null`) {
    localStorage.setItem("Name", "")
  }
  async function feedback() {
    alert(`${localStorage.getItem("Name")} welcome to the feedback. If your star rating is 5 then enter 5 if you or 4 enter 4 or 3 enter 3 or 2 enter 2 or 1 enter 1`)
    let feedback = prompt("Please enter your feedback")
    let query = null
    // let feedback="s"
    if (feedback == 5) {
      alert("Thank you very much sir/mam you like our blog 😊")
      alert("Thank you for your feedback sir/mam 👍")
    }
    else if (feedback == 4) {
      alert("Thank you sir/mam 😀")
      alert("Thank you for your feedback sir/mam 👍")
    }
    else if (feedback == 3) {
      alert("Ok sir/mam 😶")
      alert("Thank you for your feedback sir/mam 👍")
    }
    else if (feedback == 2) {
      alert("Sorry sir/mam we will improve the blog 😨")
      query = prompt("Enter the query why you are not happy with the blog please 😣")
      alert("Thank you for your feedback sir/mam 👍")
    }
    else if (feedback == 1) {
      alert("We are so sorry sir/mam we will do updates and we will improve the website 😣")
      query = prompt("Enter the query why you are not happy with the blog please 😣")
      alert("Thank you for your feedback sir/mam 👍")
    }
    else {
      alert("Sir/Mam can't understand please try again 😅")
    }
    let js = {
      Name: localStorage.getItem("Name"),
      FeedBack: feedback,
      Query: query,
    }
    if (feedback == 1 || feedback == 2 || feedback == 3 || feedback == 4 || feedback == 5) {
      await fetch("https://blog-c7e27-default-rtdb.firebaseio.com/Feedback.json",
        {
          method: "POST",
          body: JSON.stringify(js)
        })
    }
  }
  let i = 0
  let rand,ran
  rand=Math.floor(Math.random()*4)
  if(rand==0){
    ran="😎"
  }
  else if(rand==1){
    ran="😊"
  }
  else if(rand==2){
    ran="🤗"
  }
  else{
    ran="😀"
  }
  // let txt = `${ran} Hi ${localStorage.getItem("Name")} welcome to the blog`
  let speed = 50
  let txt2 = `Blogs`
  setTimeout(() => {
    // document.getElementById(`typings`).innerText = txt
    document.getElementById(`blogs`).innerText = txt2
  }, 1);
  // function typeWriter() {
  //     setInterval(() => {
  //         if (i < txt.length) {
  //             document.getElementById(`typings`).innerHTML += txt.charAt(i)
  //             document.getElementById(`blogs`).innerHTML += txt2.charAt(i)
  //             i++
  //         }
  //     }, speed);
  // }
  let notification = {
    color: 'white',
    background: 'red',
    padding: '2px 5px',
    borderRadius: '1000000px'
  }
  if (localStorage.getItem("seoBlog") === null || localStorage.getItem("seoBlog") == null || localStorage.getItem("seoBlog") == "") {
    localStorage.setItem("seoBlog", 'not')
  }
  if (localStorage.getItem("htmlsheet") === null || localStorage.getItem("htmlsheet") == null || localStorage.getItem("htmlsheet") == "") {
    localStorage.setItem("htmlsheet", 'not')
  }
  if (localStorage.getItem("hotspot") === null || localStorage.getItem("hotspot") == null || localStorage.getItem("hotspot") == "") {
    localStorage.setItem("hotspot", 'not')
  }
  if (localStorage.getItem("hostinger") === null || localStorage.getItem("hostinger") == null || localStorage.getItem("hostinger") == "") {
    localStorage.setItem("hostinger", 'not')
  }
  let webNot = 0
  let commonNot=0
  let webBlogList = document.getElementById("web-develoment-bloglist")
  let sheetNot=0
  let pCommonNot=0
  if (localStorage.getItem("seoBlog") == "not") {
    webNot++
  }
  if (localStorage.getItem("hotspot") == "not") {
    commonNot++
  }
  if(localStorage.getItem("htmlsheet") == "not"){
    sheetNot++
  }
  if (localStorage.getItem("hostinger") == "not") {
    webNot++
  }
  // if (localStorage.getItem("seoBlog") == "yes") {
  //   webNot--
  // }
  // if (localStorage.getItem("hostinger") == "yes") {
  //   webNot--
  // }
  if(localStorage.getItem("htmlsheet")=="yes"){
    sheetNot--
    sheetNot++
  }
  if(localStorage.getItem("hotspot")=="yes"){
    commonNot--
    commonNot++
  }
  function web() {
    localStorage.setItem("seoBlog", "yes")
    localStorage.setItem("hostinger", "yes")
  }
  function cheatsheet(){
    localStorage.setItem("htmlsheet","yes")
  }
  function common(){
    localStorage.setItem("hotspot","yes")
  }
  return (
    <>
      <h1 className="typing" id="typings">{ran} Hi {localStorage.getItem("Name")} welcome to the blog</h1>
      <div className="log-in-out">
        <Link className="btn btn-danger login-btn" id="Login" to="/login">Login</Link>
        <button style={{ marginLeft: "10px" }} className="btn btn-danger" onClick={logout}>Logout</button>
      </div>
      <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1405906750411457"
        crossorigin="anonymous"></script>
      <ins className="adsbygoogle"
        style={home1}
        data-ad-client="ca-pub-1405906750411457"
        data-ad-slot="3091692536"
        data-ad-format="auto"
        data-full-width-responsive="true"></ins>
      <script>
        (adsbygoogle = window.adsbygoogle || []).push({ });
      </script>
      <section className="card-card text-gray-600 body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap -m-4">
            <div className="xl:w-1/4 md:w-1/2 p-4">
              <div className="border border-gray-200 p-6 rounded-lg shadowss">
                <div
                  className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-purple-100 text-indigo-500 mb-4">
                  <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-6 h-6" viewBox="0 0 24 24">
                    <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="blogger-b" class="svg-inline--fa fa-blogger-b fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M446.6 222.7c-1.8-8-6.8-15.4-12.5-18.5-1.8-1-13-2.2-25-2.7-20.1-.9-22.3-1.3-28.7-5-10.1-5.9-12.8-12.3-12.9-29.5-.1-33-13.8-63.7-40.9-91.3-19.3-19.7-40.9-33-65.5-40.5-5.9-1.8-19.1-2.4-63.3-2.9-69.4-.8-84.8.6-108.4 10C45.9 59.5 14.7 96.1 3.3 142.9 1.2 151.7.7 165.8.2 246.8c-.6 101.5.1 116.4 6.4 136.5 15.6 49.6 59.9 86.3 104.4 94.3 14.8 2.7 197.3 3.3 216 .8 32.5-4.4 58-17.5 81.9-41.9 17.3-17.7 28.1-36.8 35.2-62.1 4.9-17.6 4.5-142.8 2.5-151.7zm-322.1-63.6c7.8-7.9 10-8.2 58.8-8.2 43.9 0 45.4.1 51.8 3.4 9.3 4.7 13.4 11.3 13.4 21.9 0 9.5-3.8 16.2-12.3 21.6-4.6 2.9-7.3 3.1-50.3 3.3-26.5.2-47.7-.4-50.8-1.2-16.6-4.7-22.8-28.5-10.6-40.8zm191.8 199.8l-14.9 2.4-77.5.9c-68.1.8-87.3-.4-90.9-2-7.1-3.1-13.8-11.7-14.9-19.4-1.1-7.3 2.6-17.3 8.2-22.4 7.1-6.4 10.2-6.6 97.3-6.7 89.6-.1 89.1-.1 97.6 7.8 12.1 11.3 9.5 31.2-4.9 39.4z"></path></svg>
                  </svg>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Blog</h2>
                <p className="leading-relaxed text-base">In this website blog we have create many blogs with step by step no
                  step is skipped.</p>
              </div>
            </div>
            <div className="xl:w-1/4 md:w-1/2 p-4">
              <div className="border border-gray-200 p-6 rounded-lg shadowss">
                <div
                  className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-purple-100 text-indigo-500 mb-4">
                  <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-6 h-6" viewBox="0 0 24 24">

                    <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="flag" class="svg-inline--fa fa-flag fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M336.174 80c-49.132 0-93.305-32-161.913-32-31.301 0-58.303 6.482-80.721 15.168a48.04 48.04 0 0 0 2.142-20.727C93.067 19.575 74.167 1.594 51.201.104 23.242-1.71 0 20.431 0 48c0 17.764 9.657 33.262 24 41.562V496c0 8.837 7.163 16 16 16h16c8.837 0 16-7.163 16-16v-83.443C109.869 395.28 143.259 384 199.826 384c49.132 0 93.305 32 161.913 32 58.479 0 101.972-22.617 128.548-39.981C503.846 367.161 512 352.051 512 335.855V95.937c0-34.459-35.264-57.768-66.904-44.117C409.193 67.309 371.641 80 336.174 80zM464 336c-21.783 15.412-60.824 32-102.261 32-59.945 0-102.002-32-161.913-32-43.361 0-96.379 9.403-127.826 24V128c21.784-15.412 60.824-32 102.261-32 59.945 0 102.002 32 161.913 32 43.271 0 96.32-17.366 127.826-32v240z"></path></svg>
                  </svg>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Features</h2>
                <p className="leading-relaxed text-base">In this blog we have explain with image with writing in any of the
                  blog. We have unique blog that you have not seen ever for a beginner</p>
              </div>
            </div>
            <div className="xl:w-1/4 md:w-1/2 p-4">
              <div className="border border-gray-200 p-6 rounded-lg shadowss">
                <div
                  className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-purple-100 text-indigo-500 mb-4">
                  <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-6 h-6" viewBox="0 0 24 24">
                    <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="blogger-b" class="svg-inline--fa fa-blogger-b fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M446.6 222.7c-1.8-8-6.8-15.4-12.5-18.5-1.8-1-13-2.2-25-2.7-20.1-.9-22.3-1.3-28.7-5-10.1-5.9-12.8-12.3-12.9-29.5-.1-33-13.8-63.7-40.9-91.3-19.3-19.7-40.9-33-65.5-40.5-5.9-1.8-19.1-2.4-63.3-2.9-69.4-.8-84.8.6-108.4 10C45.9 59.5 14.7 96.1 3.3 142.9 1.2 151.7.7 165.8.2 246.8c-.6 101.5.1 116.4 6.4 136.5 15.6 49.6 59.9 86.3 104.4 94.3 14.8 2.7 197.3 3.3 216 .8 32.5-4.4 58-17.5 81.9-41.9 17.3-17.7 28.1-36.8 35.2-62.1 4.9-17.6 4.5-142.8 2.5-151.7zm-322.1-63.6c7.8-7.9 10-8.2 58.8-8.2 43.9 0 45.4.1 51.8 3.4 9.3 4.7 13.4 11.3 13.4 21.9 0 9.5-3.8 16.2-12.3 21.6-4.6 2.9-7.3 3.1-50.3 3.3-26.5.2-47.7-.4-50.8-1.2-16.6-4.7-22.8-28.5-10.6-40.8zm191.8 199.8l-14.9 2.4-77.5.9c-68.1.8-87.3-.4-90.9-2-7.1-3.1-13.8-11.7-14.9-19.4-1.1-7.3 2.6-17.3 8.2-22.4 7.1-6.4 10.2-6.6 97.3-6.7 89.6-.1 89.1-.1 97.6 7.8 12.1 11.3 9.5 31.2-4.9 39.4z"></path></svg>
                  </svg>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Number of blogs</h2>
                <h1 className="font-medium leading-relaxed text-base">25</h1>
              </div>
            </div>
            <div className="xl:w-1/4 md:w-1/2 p-4">
              <div className="border border-gray-200 p-6 rounded-lg shadowss">
                <div
                  className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-purple-100 text-indigo-500 mb-4">
                  <svg fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-6 h-6" viewBox="0 0 24 24">

                    <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="comments" class="svg-inline--fa fa-comments fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M532 386.2c27.5-27.1 44-61.1 44-98.2 0-80-76.5-146.1-176.2-157.9C368.3 72.5 294.3 32 208 32 93.1 32 0 103.6 0 192c0 37 16.5 71 44 98.2-15.3 30.7-37.3 54.5-37.7 54.9-6.3 6.7-8.1 16.5-4.4 25 3.6 8.5 12 14 21.2 14 53.5 0 96.7-20.2 125.2-38.8 9.2 2.1 18.7 3.7 28.4 4.9C208.1 407.6 281.8 448 368 448c20.8 0 40.8-2.4 59.8-6.8C456.3 459.7 499.4 480 553 480c9.2 0 17.5-5.5 21.2-14 3.6-8.5 1.9-18.3-4.4-25-.4-.3-22.5-24.1-37.8-54.8zm-392.8-92.3L122.1 305c-14.1 9.1-28.5 16.3-43.1 21.4 2.7-4.7 5.4-9.7 8-14.8l15.5-31.1L77.7 256C64.2 242.6 48 220.7 48 192c0-60.7 73.3-112 160-112s160 51.3 160 112-73.3 112-160 112c-16.5 0-33-1.9-49-5.6l-19.8-4.5zM498.3 352l-24.7 24.4 15.5 31.1c2.6 5.1 5.3 10.1 8 14.8-14.6-5.1-29-12.3-43.1-21.4l-17.1-11.1-19.9 4.6c-16 3.7-32.5 5.6-49 5.6-54 0-102.2-20.1-131.3-49.7C338 339.5 416 272.9 416 192c0-3.4-.4-6.7-.7-10C479.7 196.5 528 238.8 528 288c0 28.7-16.2 50.6-29.7 64z"></path></svg>
                  </svg>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Feedback</h2>
                <h1 className="font-medium leading-relaxed text-base">Tell us about your feedback click the button to give
                  feedback. <br /> <button className="btn btn-danger" id="Feed" onClick={feedback}>Feedback</button></h1>
              </div>
            </div>
          </div>
        </div>
      </section>
      <h1 style={home2} className="headin text-center" id="blogs"></h1>
      <section style={home2} className="text-gray-600 body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap -m-4">
            <div className="xl:w-1/3 md:w-1/2 p-4">
              <div className="shadowss border border-gray-200 p-6 rounded-lg shadowss">
                <div className=" w-10 h-10 inline-flex items-center justify-center rounded-full bg-red-100 text-red-500 mb-4">
                  <Link style={{ marginTop: "-4px" }} to="/python-bloglist" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-7  h-7" viewBox="0 0 24 24">
                    <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="python" class="svg-inline--fa fa-python fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M439.8 200.5c-7.7-30.9-22.3-54.2-53.4-54.2h-40.1v47.4c0 36.8-31.2 67.8-66.8 67.8H172.7c-29.2 0-53.4 25-53.4 54.3v101.8c0 29 25.2 46 53.4 54.3 33.8 9.9 66.3 11.7 106.8 0 26.9-7.8 53.4-23.5 53.4-54.3v-40.7H226.2v-13.6h160.2c31.1 0 42.6-21.7 53.4-54.2 11.2-33.5 10.7-65.7 0-108.6zM286.2 404c11.1 0 20.1 9.1 20.1 20.3 0 11.3-9 20.4-20.1 20.4-11 0-20.1-9.2-20.1-20.4.1-11.3 9.1-20.3 20.1-20.3zM167.8 248.1h106.8c29.7 0 53.4-24.5 53.4-54.3V91.9c0-29-24.4-50.7-53.4-55.6-35.8-5.9-74.7-5.6-106.8.1-45.2 8-53.4 24.7-53.4 55.6v40.7h106.9v13.6h-147c-31.1 0-58.3 18.7-66.8 54.2-9.8 40.7-10.2 66.1 0 108.6 7.6 31.6 25.7 54.2 56.8 54.2H101v-48.8c0-35.3 30.5-66.4 66.8-66.4zm-6.7-142.6c-11.1 0-20.1-9.1-20.1-20.3.1-11.3 9-20.4 20.1-20.4 11 0 20.1 9.2 20.1 20.4s-9 20.3-20.1 20.3z"></path></svg>
                  </Link>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Python BlogList</h2>
                <p className="leading-relaxed text-base">In this BlogList you will be able to see all of the python tricks and
                  python skills available not programming but some of tricks. Some important things tricks that you have not
                  seen before.<br /> <Link to="/python-bloglist"> <button className="btn btn-outline-primary">Python
                    BlogList <sup style={notification}>0</sup></button></Link></p>
              </div>
            </div>
            <div className="xl:w-1/3 md:w-1/2 p-4">
              <div className="shadowss border border-gray-200 p-6 rounded-lg shadowss">
                <div className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-red-100 text-red-500 mb-4">
                  <Link to="/web-develoment-bloglist" style={{ marginTop: "-5px" }} fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-6 h-6" viewBox="0 0 24 24">
                    <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="html5" class="svg-inline--fa fa-html5 fa-w-12" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M0 32l34.9 395.8L191.5 480l157.6-52.2L384 32H0zm308.2 127.9H124.4l4.1 49.4h175.6l-13.6 148.4-97.9 27v.3h-1.1l-98.7-27.3-6-75.8h47.7L138 320l53.5 14.5 53.7-14.5 6-62.2H84.3L71.5 112.2h241.1l-4.4 47.7z"></path></svg>
                  </Link>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Web Development BlogList</h2>
                <p className="leading-relaxed text-base">In this BlogList you will be able to see all of the web development
                  tricks and web development important skills not programming but fun tricks. <Link
                    to="/web-develoment-bloglist"><button onClick={web} className="btn btn-outline-primary">Web Development BlogList <sup style={notification}>{webNot}</sup></button></Link>
                </p>
              </div>
            </div>
            <div className="xl:w-1/3 md:w-1/2 p-4">
              <div className="shadowss border border-gray-200 p-6 rounded-lg shadowss">
                <div className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-red-100 text-red-500 mb-4">
                  <Link to="/common-bloglist" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-7 h-7" viewBox="0 0 24 24">


                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="desktop" class="svg-inline--fa fa-desktop fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path fill="currentColor" d="M528 0H48C21.5 0 0 21.5 0 48v320c0 26.5 21.5 48 48 48h192l-16 48h-72c-13.3 0-24 10.7-24 24s10.7 24 24 24h272c13.3 0 24-10.7 24-24s-10.7-24-24-24h-72l-16-48h192c26.5 0 48-21.5 48-48V48c0-26.5-21.5-48-48-48zm-16 352H64V64h448v288z"></path></svg>
                  </Link>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Common BlogList</h2>
                <p className="leading-relaxed text-base">In this BlogList, you can see all of the common computer tricks that
                  you have not seen ever. Fun tricks about computer that can be used for you producivity.<br /><Link to="/common-bloglist">
                    <button onClick={common} className="btn btn-outline-primary">Common BlogList <sup style={notification}>{commonNot}</sup></button></Link></p>
              </div>
            </div>
            <div className="xl:w-1/3 md:w-1/2 p-4">
              <div className="shadowss border border-gray-200 p-6 rounded-lg shadowss">
                <div className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-red-100 text-red-500 mb-4">
                  <Link to="/programming-common-bloglist" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-7 h-7" viewBox="0 0 24 24">
                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="code" class="svg-inline--fa fa-code fa-w-20" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M278.9 511.5l-61-17.7c-6.4-1.8-10-8.5-8.2-14.9L346.2 8.7c1.8-6.4 8.5-10 14.9-8.2l61 17.7c6.4 1.8 10 8.5 8.2 14.9L293.8 503.3c-1.9 6.4-8.5 10.1-14.9 8.2zm-114-112.2l43.5-46.4c4.6-4.9 4.3-12.7-.8-17.2L117 256l90.6-79.7c5.1-4.5 5.5-12.3.8-17.2l-43.5-46.4c-4.5-4.8-12.1-5.1-17-.5L3.8 247.2c-5.1 4.7-5.1 12.8 0 17.5l144.1 135.1c4.9 4.6 12.5 4.4 17-.5zm327.2.6l144.1-135.1c5.1-4.7 5.1-12.8 0-17.5L492.1 112.1c-4.8-4.5-12.4-4.3-17 .5L431.6 159c-4.6 4.9-4.3 12.7.8 17.2L523 256l-90.6 79.7c-5.1 4.5-5.5 12.3-.8 17.2l43.5 46.4c4.5 4.9 12.1 5.1 17 .6z"></path></svg>
                  </Link>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">Programming Common BlogList</h2>
                <p className="leading-relaxed text-base">In this BlogList, you can see all common tricks and tips in programming
                  that will help you a lot. This BlogList is very fun and simple tricks and tips that will help you to
                  improve your programming skills and knowledge<br /><Link to="/programming-common-bloglist"><button
                    className="btn btn-outline-primary">Programming Common BlogList <sup style={notification}>{pCommonNot}</sup></button></Link></p>
              </div>
            </div>
            {/* CheatSheet BlogList */}
            <div className="xl:w-1/3 md:w-1/2 p-4">
              <div className="shadowss border border-gray-200 p-6 rounded-lg shadowss">
                <div className="w-10 h-10 inline-flex items-center justify-center rounded-full bg-red-100 text-red-500 mb-4">
                  <Link style={{marginTop:"-6px"}} to="/cheatsheet-bloglist" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    className="w-6 h-6" viewBox="0 0 24 24">
                  
<svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="copy" class="svg-inline--fa fa-copy fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M433.941 65.941l-51.882-51.882A48 48 0 0 0 348.118 0H176c-26.51 0-48 21.49-48 48v48H48c-26.51 0-48 21.49-48 48v320c0 26.51 21.49 48 48 48h224c26.51 0 48-21.49 48-48v-48h80c26.51 0 48-21.49 48-48V99.882a48 48 0 0 0-14.059-33.941zM266 464H54a6 6 0 0 1-6-6V150a6 6 0 0 1 6-6h74v224c0 26.51 21.49 48 48 48h96v42a6 6 0 0 1-6 6zm128-96H182a6 6 0 0 1-6-6V54a6 6 0 0 1 6-6h106v88c0 13.255 10.745 24 24 24h88v202a6 6 0 0 1-6 6zm6-256h-64V48h9.632c1.591 0 3.117.632 4.243 1.757l48.368 48.368a6 6 0 0 1 1.757 4.243V112z"></path></svg>
                  </Link>
                </div>
                <h2 className="text-lg text-gray-900 font-medium title-font mb-2">CheatSheet BlogList</h2>
                <p className="leading-relaxed text-base">In this BlogList, you can see the CheatSheet of programming languages like Python , Java and HTML etc. We will provide you a copy button when a hover on the code area it help you to copy the all code of a code area.<br /><Link to="/cheatsheet-bloglist"><button onClick={cheatsheet}
                    className="btn btn-outline-primary">CheatSheet BlogList <sup style={notification}>{sheetNot}</sup></button></Link></p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <ins className="adsbygoogle"
        style={home1}
        data-ad-client="ca-pub-1405906750411457"
        data-ad-slot="1392625729"
        data-ad-format="auto"
        data-full-width-responsive="true"></ins>
      <script>
        (adsbygoogle = window.adsbygoogle || []).push({ });
      </script>
      <iframe src="https://theblog.co.in/traffic.html" style={{ display: "none" }} frameborder="0"></iframe>
    </>
  )
}
