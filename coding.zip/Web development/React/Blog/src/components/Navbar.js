import React from 'react';
import "./navbar.css"
// import './bootstrap.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
export default function Navbar() {
    let nav1={
        fontWeight:"bolder"
    }
    return (
        <>
          <nav>
        <Link to="/"><img src="https://theblog.co.in/icon.png" alt="logo" className="logo"/></Link>
        <h1 className="brand"><Link style={nav1} className="brand" to="/">Blog</Link></h1>
        <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About us</Link></li>
            <li><Link to="/contact">Contact us</Link></li>
            <li><Link to="/login">Login</Link></li>
        </ul>
    </nav><br/><br/>
        </>
    )
}
