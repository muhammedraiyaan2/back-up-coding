import React from 'react'
import "./style.css"
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
export default function ProgrammingCommonBlogList() {
    let style1={
        marginLeft:"15px",
        width:"120px",
        height:"240px"
    }
    document.title = "Blog - Programming Common BlogList"
    return (
        <>
  {/*blog5*/}
  <h1 class="heading2 text-center style"><Link to="/react-vs-angular-blog20">React vs Angular <div class="badge">New</div>
      <button class="btn btn-outline-danger">Read more <i class="fal fa-info-circle"></i></button></Link></h1>
  <br/>
  <hr/>
  {/*blog4*/}
  <h1 class="heading2 text-center style"><Link to="/learn-how-to-use-visual-studio-code-blog18">Learn how to use Visual Studio Code <button
        class="btn btn-outline-danger">Read more <i class="fal fa-info-circle"></i></button></Link></h1>
  <br/>
  <hr/>
  {/*blog3*/}
  <h1 class="heading2 text-center style"><Link to="/how-to-install-visual-studio-code-blog16">How to install Visual Studio Code in Windows <button
        class="btn btn-outline-danger">Read more <i class="fal fa-info-circle"></i></button></Link></h1>
  <br/>
  <hr/>
  {/*blog2*/}
  <h1 class="heading2 text-center style"><Link to="/top3-web-frameworks-blog13">Top 3 Web FrameWork <button
        class="btn btn-outline-danger">Read more <i class="fal fa-info-circle"></i></button></Link></h1>
  <br/>
  <hr/>
  {/* blog1 */}
  <h1 class="heading2 text-center style"><Link to="/top5-programmming-languages-blog12">Top 5 programming languages <button
        class="btn btn-outline-danger">Read more <i class="fal fa-info-circle"></i></button></Link></h1>
  <br/>
  <br/>
       <div style={{display: 'flex', flexWrap:"wrap"}}>
    <iframe style={style1} marginwidth="0" marginheight="0" scrolling="no" frameborder="0"
      src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=none0b92-21&language=en_IN&marketplace=amazon&region=IN&placement=B087FXHB6J&asins=B087FXHB6J&linkId=2f11778e50b661aa81c92d1eed17b62e&show_border=true&link_opens_in_new_window=true"></iframe>
    <iframe style={style1}       frameborder="0"
      src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=none0b92-21&language=en_IN&marketplace=amazon&region=IN&placement=B01HJI0FS2&asins=B01HJI0FS2&linkId=c7f7556450224c1b5d3ceabb4ad7550c&show_border=true&link_opens_in_new_window=true"></iframe>
      <iframe style={style1} frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=none0b92-21&language=en_IN&marketplace=amazon&region=IN&placement=B008QS9J6Y&asins=B008QS9J6Y&linkId=d3a6aeb76b35c0a271284133551689fe&show_border=true&link_opens_in_new_window=true"></iframe>
  </div>
        </>
    )
}
