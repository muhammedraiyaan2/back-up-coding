import React from 'react'
import {
      BrowserRouter as Router,
      Switch,
      Route,
      Link
} from "react-router-dom";
export default function CommonBlogList() {
      document.title = "Blog - Common BlogList"
      return (
            <>
            {/* Blog 7 */}
            <h1 className="heading2 text-center"><Link to="/how-to-turn-on-hotspot-in-laptop-blog24">How to turn on hotspot in laptop in windows 10 & 11 <div
                  className="badge">New
            </div> <button className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            {/* Blog 6 */}
            <h1 className="heading2 text-center"><Link to="/top-5-google-chorme-extensions-blog21">5 Useful Google Chorme Extensions <button className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            {/* Blog 5 */}
            <h1 className="heading2 text-center"><Link to="/how-to-type-in-other-language-in-windows-10-blog15">How to type in other languages in windows 10 <button className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            {/* Blog 4 */}
            <h1 className="heading2 text-center"><Link to="how-to-use-google-chomre-as-text-editor-blog14">How to use Google Chorme as text editor <button className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            {/* Blog 3 */}
            <h1 className="heading2 text-center"><Link to='/15-google-chorme-shortcuts-blog10'>15 Google Chorme keyboard shortcuts <button
                  className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            {/* Blog 2 */}
            <h1 className="heading2 text-center"><Link to="/15-keyboard-shortcut-for-windows-blog9">15 Keyboard shortcuts for windows <button
                  className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            {/* Blog 1 */}
            <h1 className="heading2 text-center"><Link to="/command-prompt-cool-tricks-blog7">Command Prompt cool tricks <button
                  className="btn btn-outline-primary">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
            <br />
            <hr />
            <br /><br /><br />
            </>
      )
}
