import React from 'react'
import "./style.css"
import {
      BrowserRouter as Router,
      Switch,
      Route,
      Link
    } from "react-router-dom";
export default function WebDevelopmentBlogList() {
    document.title = `Blog - Web Development BlogList`
    return (
        <>
  <h1 className="heading2 text-center"><Link to="/the-best-web-hosting-platform-blog25">The best web hosting platform for web developers <div className="badge">New</div>
  <button className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/what-is-seo-how-to-improve-seo-blog22">What is SEO? How to improve SEO <button className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/7-web-development-tools-blog19">7 Web Development tools <button className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/what-is-lighthouse-how-to-use-lighthouse-blog17">What is light house and how to use light house in
      chorme <button className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/11-web-development-projects-blog8">11 Web development projects <button
        className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/how-to-keep-your-code-safe-blog6">How to keep your code safe<button
        className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/about-repl-the-online-ide-blog5">About repl the online IDE <button
        className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <h1 className="heading2 text-center"><Link to="/how-to-deploy-a-website-github-blog1">How to deploy a website in github <button
        className="btn btn-outline-success">Read more <i className="fal fa-info-circle"></i></button></Link> </h1>
  <br/>
  <hr/>
  <br /><br />
        </>
    )
}
