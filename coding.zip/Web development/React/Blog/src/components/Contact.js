import React from 'react'

export default function Contact() {
    document.title = `Blog - Contact us`
    return (
        <>
        <h1 class="contact text-center">Mail: support@theblog.co.in</h1>
  <h1 class="contact text-center">Github: <a href="https://github.com/muhammedraiyaan2" class="a" target="_blank" title="Open my github profile">Click here to open my github profile</a></h1>
  <h1 class="contact text-center">For more details go to: <a href="https://muhammedraiyaan2.github.io/Profile" class="a" target="_blank" title="Open my profile">Click here to open my profile</a></h1><br/><br/><br/>
    <br/><br/><br/>    <br/><br/><br/>
    <br/><br/><br/>    <br/><br/><br/>
    <br/><br/><br/>    <br/></>
    )
}
