import React from 'react'

export default function Blog9() {
    document.title = '15 Keyboard shortcuts for windows'
    return (
        <>
        <h1 className="heading text-center">15 Keyboard shortcuts for windows</h1><br/><br/>
    <br/><br/>
    <dl>
        <dt>
            <h1 className="heading">Shortcuts:</h1><br/>
        </dt>
        <dd>
            <p>1. <kbd>Windows+D</kbd> This Keyboard shortcut will go to desktop it minimize (Works for any windows).</p><br/>
            <p>2. <kbd>AltTtab</kbd> This Keyboard shortcut will switch programs (Works for any windows).</p><br/>
            <p>3. <kbd>Ctrl+Windows+D</kbd> This keyboard shortcut will create a new desktop when you do this you feel that all your programs as been closed but not, press <kbd>Windows+Tab</kbd> And there will be a option desktop 1 and desktop 2 click on desktop 1 and you can able go to the desktop 1 and when ever you want to switch to desktop 2 and follow the same steps (Works for only windows 10).</p>
            <p>4. <kbd>Windows+L</kbd> This keyboard shortcut will lock the computer and you have to unlock when ever you want to unlock (Works for any windows).</p><br/>
            <p>5. <kbd>Windows+E</kbd> This keyboard shortcut will open file explorer (Works for any windows).</p><br/>
            <p>6. <kbd>Windows+number</kbd> In this keyboard shortcut you have press windows + any number from 0 to 9 what happens in this shortcut is example see in the taskbar first program shortcut is windows+1 second program in the taskbar is window+2 etc (Works for any windows).</p><br/>
            <p>7. <kbd>Windows+S</kbd> This keyboard shortcut search anything that you want to search (Works only windows 10).</p><br/>
            <p>8. <kbd>Windows+V</kbd> When you press this keyboard shortcut a dialog box will open and it say that could you want to allow the history of the clipboard click on and you can able to see the copied clipboard history (Works for only windows 10).</p><br/>
            <p>9. <kbd>Windows+R</kbd> This keyboard shortcut will open run command (Works for any windows).</p><br/>
            <p>10. <kbd>Windows+X</kbd> This keyboard shortcut will open  dialog box that shows show option like terminal or powershell run etc (For windows 10). For windows 7 or 8 when press the keyboard shortcut you can see a dialog box that shows battery brightness etc (For any windows not for windows 10).</p><br/>
            <p>11. <kbd>Windows+P</kbd> This keyboard shortcut helps you to connect multiply screen (For any windows).</p><br/>
            <p>12. <kbd>Ctrl+Shift+Esc</kbd> This keyboard shortcut open taskbar manager (For any windows).</p><br/>
            <p>13. <kbd>Windows+PrtSc</kbd> This keyboard shortcut will take a screenshot and save the screenshots in pictures (For only windows 10).</p><br/>
            <p>14. <kbd>Windows+A</kbd> This keyboard shortcut will show you some option (for only windows 10).</p><br/>
            <p>15. <kbd>Windows+H</kbd> In this keyboard shortcut A dialog box will be open where you can say something and it will type for you (For only windows 10).</p>
        </dd>
    </dl>
        </>
    )
}
