import React from 'react'
import "./style.css"
export default function Blog21() {
    document.title = 'Blog - How to turn on hotspot in laptop in windows 10 & 11'
    return (
        <>
            <h1 class="heading text-center">How to turn on hotspot in laptop in windows 10 & 11</h1>
            <p className="description">Make Sure that your connected to internet</p>
            <br/>
            <h1 class="headings">Steps</h1>
            <p><b>1.</b> Open settings</p>
            <p><b>2.</b> Go to Network and Internet</p>
            <img src="https://theblog.co.in/media/Open network and internet in settings.png" alt="Open network and internet in settings" className="image_size" />
            <p><b>3.</b> Go to Mobile Hotspot</p>
            <img src="https://theblog.co.in/media/Go to mobile hotspot.png" alt="Go to mobile hotspot" className="image_size" />
            <p><b>4.</b> Turn on Mobile Hotspot</p>
            <img src="https://theblog.co.in/media/Turn on the mobile hotspot.png" alt="Turn on the mobile hotspot" className="image_size" />
            <p><b>5.</b> If you want you can edit the form click on edit button in properties box and edit. You can edit name, password and band. After editing click on Save</p>
            <p><b>Testing:</b> Go to your phone and turn on WiFi and connect the hotspot from your laptop and enter the password and you are connected from your laptop</p>
            <br />
            <p className="red-font">If you like this blog please like this blog are you think that this blog is not giving full guide or something else please comment below we see all your comments and listen to you people</p>
            <br/>
            <iframe src="https://theblog.co.in/iframe/howtoturnonmobilehotspotinlaptop.html" frameborder="0" className="social"></iframe>
    </>
    )
}
