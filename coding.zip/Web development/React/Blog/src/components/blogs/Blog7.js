import React from 'react'

export default function Blog7() {
    document.title = 'Command Prompt cool tricks'
    return (
        <>
            <h1 class="heading text-center">Command Prompt cool tricks</h1><br/><br/>
<br/><br/>
    <dl>
        <dt>
            <h1 class="heading">Tricks:</h1>
        </dt>
        <dd>
          <p>1. Changing the text color in command prompt. Write help color and you can get some numbers like 1 2 3 etc and letters like a b c etc. If you want light green color then write color a. What color you want you can change the color by the color code.</p>
          <img src="https://theblog.co.in/media/command prompt changing the color.png" alt="image" class="image_size"/>
          <p>2. Change the title of the command prompt. You write title and title name example title Hacking the system.</p>
          <img src="https://theblog.co.in/media/command prompt changing the title.png" alt="image" class="image_size"/>
          <p>3. Changing the title input of command prompt. You can chnage the title input by this command write prompt and write the title name and write $G example prompt Hacker$G and press enter you can see the change.</p>
          <img src="https://theblog.co.in/media/command prompt changing the title input.png" class="image_size" alt="image"/>
          <p>4. Hide or show a folder. You can hide or show a folder with command prompt you have to open the command prompt in that folder where you want to hide the folder you can simply write cmd in the url bar and you can able to open command prompt in that folder and write Attrib +h +s +r folder_name and you can hide the folder. If you want to show that folder then write Attrib -h -s -r folder_name. If you have hide the folder and you want to access the folder then go to the parent folder and write back slash write the folder name</p>
          <br/><p>5. Copy the output. If you want to copy command text you can use this trick that is example help color | clip. The help color will copy.</p>
          <img src="https://theblog.co.in/media/command prompt copy.png" alt="image" class="image_size"/>
          <p>6. Want to know the Ip address of your computer then write ipconfig</p>
          <img src="https://theblog.co.in/media/command prompt ipconfig.png" alt="image" class="image_size"/>
          <p>7. See the history of command prompt press F7 on your keyboard</p>
          <img src="https://theblog.co.in/media/command prompt history.png" alt="image" class="image_size"/>
          <p>8. Make a folder name con it will show you error but you can create the this folder by simple command in command prompt that is md con\ and press enter and you able to create the folder name con and you can challenge your friend 😜.</p>
          <p>9. You can see the installed programs with command prompt write wmic product get name and press enter it takes some time but it will print the programs details.</p>
          <img src="https://theblog.co.in/media/command prompt programs list.png" alt="image" class="image_size"/>
        </dd>
    </dl>
        </>
    )
}
