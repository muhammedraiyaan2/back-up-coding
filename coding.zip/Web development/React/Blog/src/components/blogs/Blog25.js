import React from 'react'
import "./style.css"
export default function Blog21() {
    document.title = 'Blog - The best web hosting platform for web developers'
    return (
        <>
            <h1 class="heading text-center">The best web hosting platform for web developers</h1>
            <p className="description"><b>Note:</b> This blog is not sponsored by any company. This blog only recommends that this platform is best with the reason why is the platform best.</p>
            {/* <h1 class="headings">Steps</h1> */}
            <p><b>Hostinger:</b> is the best platform for web hosting because</p>
            <div style={{marginLeft: '10px',fontSize: '20px'}}>
            <li>Easy to use</li>
            <li>Best hosting and domain for very cheap</li>
            <li>Value for money</li>
            <li>30 days money back guarantee</li>
            <li>Free SSL certificate</li>
            <li>Free email account</li>
            <li>Free domain (for only premium and higher plans)</li>
            <li>WordPress acceleration</li>
            <li>Free MySql DataBase</li>
            <li>SSH and Git access</li>
            </div><br />
            <p class="text-center b">The plans are shown below</p><br />
            <img src="https://theblog.co.in/media/hostinger plans.png" alt="hostinger plans" className="image_size" />
            <p><b>Note:</b> Don't forget to use the coupon code <kbd>THAPA7</kbd> for additional discount.</p>
            <p className="red-font">If you like this blog please like this blog are you think that this blog is not giving full guide or something else please comment below we see all your comments and listen to you people</p>
            <br/>
            <iframe src="https://theblog.co.in/iframe/thebestwebhostingplatform.html" frameborder="0" className="social"></iframe>
    </>
    )
}
