import React from 'react'
import "./style.css"
export default function Blog11() {
    document.title = `Blog - 5 Python Projects`
    return (
        <>
        <h1 className="heading text-center">5 Python Projects</h1><br/><br/>
    <h2 className="description text-center">We have 2 hard project, 1 medium project and 2 easy projects</h2>
    <br/><br/>
    <dl>
        <dt>
            <h1 className="heading">Projects:</h1><br/>
        </dt>
        <dd>
            <p><b>1. Image Editor with GUI:</b> This software will only crop the image not any do any complicate works. You can add a new feature like filtering images etc.</p>
            <p><b>2. Desktop Assistant:</b> This software will help you to do some things that help you out and this software have to speak and listen the command in voice you have to not type you have to speak something and it will do for you this software will help a lot because cortana can't help you with everthing if you notice some problem in cortana then you can add to your Dsktop Assistant.</p>
            <p><b>3. Notificating Software: </b> This software will help you remind to drink water in every hour you have to use the plyer module for this project.</p>
            <p><b>4. Rock Paper Sccisor Game: </b> This game will help you to play game with computer.</p>
            <p><b>5. Dice Similator:</b> This software will help you to print the random number range 1 to 6 this helps when you want to play ludo game and you can use this software.</p>

        </dd>
    </dl>
        </>
    )
}
