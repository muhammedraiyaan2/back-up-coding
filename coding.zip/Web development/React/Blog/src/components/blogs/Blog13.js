import React from 'react'

export default function Blog13() {
    document.title = 'Blog - Top 3 web frameworks'
    return (
        <>
        <h1 class="heading text-center">Top 3 Web FrameWork</h1><br/><br/>
    <h2 class="description text-center"><b>Note:</b> This blog is not sponsored by any company this shows the real data.</h2>
    <br/><br/>
    <dl>
        <dt>
            <h1 class="headings">Programming Languages:</h1><br/>
        </dt>
        <dd>
            <p><b>1. React</b> is the most popular web framework for developing single page applications the demand of this framework is very top compared other single page application framework. React is developed by FaceBook which is a JavaScript framework.</p>
            <img src="https://theblog.co.in/media/web framework.png" alt="web framework" class="image_size"/>
            <p><b>2. Angular</b> is the most popular web framework for developing single page applications the demand of this framework is high. Angular is developed by Google which is a TypeScript FrameWork.</p>
            <p><b>3. Django</b> is most popular framework for developing website backend which is a python framework. Django has a lots of community <b>Ex:</b> if you got a error there is a chance that there will be a blog or a stackoverflow query.</p>
        </dd>
    </dl>
        </>
    )
}
