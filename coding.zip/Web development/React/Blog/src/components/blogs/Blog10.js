import React from 'react'

export default function Blog10() {
    document.title = '15 Google Chrome keyboard shortcuts'
    return (
        <>
        <h1 class="heading text-center">15 Google Chrome keyboard shortcuts</h1><br/><br/>
    <br/><br/>
    <dl>
        <dt>
            <h1 class="heading">Shortcuts:</h1><br/>
        </dt>
        <dd>
           <p>1. <kbd>Ctrl+W</kbd> This shortcut will close the current tab.</p>
           <p>2. <kbd>Ctrl+H</kbd> This shortcut will open history.</p>
           <p>3. <kbd>Ctrl+T</kbd> This shortcut will open a new tab.</p>
           <p>4. <kbd>Ctrl+O</kbd> This shortcut will open a file that you want to open in chrome.</p>
           <p>5. <kbd>Ctrl+Shift+T</kbd> This shortcut will open recent closed tab also when you close your chorme browser you want the tabs back you can use this shortcut.</p>
           <p>6. <kbd>Ctrl+J</kbd> This shortcut will open downloads.</p>
           <p>7. <kbd>Ctrl+N</kbd> This shortcut will open a new window.</p>
           <p>8. <kbd>Ctrl+Shift+W</kbd> This shortcut will close the current window.</p>
           <p>9. <kbd>Ctrl+Shift+B</kbd> This shortcut will hide or unhide the bookmark lists.</p>
           <p>10. <kbd>Ctrl+Shift+O</kbd> This shortcut will open bookmark lists.</p>
           <p>11. <kbd>Alt+D</kbd> This shortcut will jump to url bar.</p>
           <p>12. <kbd>Ctrl+D</kbd> This shortcut will bookmark the current tab.</p>
           <p>13. <kbd>Ctrl+Number</kbd> This shortcut will swithc to a tab you have to press Ctrl+num for to switch the tab ex Ctrl+2 two switch the tab. I can switch two second tab.</p>
           <p>14. <kbd>Ctrl+Tab</kbd> This shortcut will switch the tabs.</p>
           <p>15. <kbd>Shift+Esc</kbd> This shortcut will open chrome task manager.</p>
        </dd>
    </dl>
        </>
    )
}
