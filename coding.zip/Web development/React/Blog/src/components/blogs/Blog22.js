import React from 'react'
import "./style.css"
export default function Blog21() {
    document.title = 'What is SEO? How to improve SEO'
    return (
        <>
            <h1 class="heading text-center">What is SEO? How to improve SEO</h1>
            <p class="description"><b>What is SEO?</b><br/> SEO full form is Search Engine Optimization which is used by all search engines like Google and Bing etc. It helps search engines to find the best website for the user search. SEO is written in HTML Meta tag.</p>
            <br/>
            <h1 class="headings">How to improve SEO</h1>
            <p><b>1. Best URL Slug:</b> helps the search engine to find the realted URL page. Sometimes you will see in some website the /url is not explain what will the webpage will provide you example https://www.youtube.com/embed/lChOVm2SeH8 we can't understand it and the search engine will not be able to find the realted URL. When ever to link a webpage please name the file to the realted webpage example you can see in the blog url.</p>
            <p><b>2. Best Title:</b> Whenever you create a new page please make sure that the title in best for the page.</p>
            <p><b>3. Write description of the page:</b> Whenever you create a page please add a description for the page this is the main source where search engines will look for. Copy this HTML code and paste in head tag &lt;meta name="description" content="Write your description here..."&gt;</p>
            <p><b>4. Write keywords of the page:</b> Whenever you create a page please add keywords for the page this helps the search engines to find keywords from the site. In keywords you write a query of the page like Blog you have keep the keywords is Blog if anyone search Blog there is a chance your site will be shown in google or in other search engines. Copy this HTML code and paste in &lt;meta name="keywords" content="Write your keywords here..."&gt;</p>
            <p><b>5. Write author of the page:</b> Whenever you create a page please add author name because search engines will look for author name also. Copy this HTML code and paste in head tag &lt;meta name="author" content="Write the author name here..."&gt;</p><br />
            <p style={{color: 'red'}}>If you like the blog please like or dislike or you want to tell something about the blog how to improve the blog ideas or you can comment this trick can also improve SEO we want to know from you. Comment below how to many tricks you know to improve SEO or you can comment this also improve the SEO.</p>
            <br/>
            <iframe className="social" src="https://theblog.co.in/iframe/seo.html" frameborder="0"></iframe>
    </>
    )
}
