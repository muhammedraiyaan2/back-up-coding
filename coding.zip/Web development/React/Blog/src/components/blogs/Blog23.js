import React from 'react'

export default function Blog23() {
    let body={
        width: '100%',
        height: '770vh',
    }
    return (
        <>
            <iframe style={body} src="https://muhammedraiyaan2.github.io/HTML-CheatSheet/" frameborder="0"></iframe>
            <iframe className="social" src="https://theblog.co.in/iframe/htmlsheet.html" frameborder="0"></iframe>
        </>
    )
}
