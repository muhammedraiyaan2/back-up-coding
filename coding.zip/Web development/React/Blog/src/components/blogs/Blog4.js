import React from 'react'
import './style.css'
export default function Blog4() {
    document.title = `Blog - How to make a http server in python`
    return (
       <>
           <h1 className="heading text-center">How to make a http server in python (3 STEPS)</h1><br/><br/>
    <dl>
        <dt><h1 className="heading">Steps:</h1></dt>
        <dd>
            <p>1. Go to your folder where you want to start the server in the address bar type powershell or cmd and press enter and then the terminal will open on the folder</p>
            <img src="https://theblog.co.in/media/python%20-m%20http.server.png" alt="image" className="image_size"/>
            <p>2. You have to type python -m http.server and press enter</p>
            <img src="https://muhammedraiyaan2.github.io/Server/python -m http.server.png" className="image_size" alt="image"/>
            <p>3. Open the browser and type localhost:8000. Please don't exit the terminal if the work is finished then you can exit the terminal</p>
        </dd>
    </dl>
       </>
    )
}
