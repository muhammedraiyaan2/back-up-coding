import React from 'react'
import "./style.css"
export default function Blog8() {
    document.title = `Blog - 11 Web Development projects`
    return (
       <>
        <h1 className="heading text-center">11 Web development projects</h1><br/><br/>
    <br/><br/>
    <dl>
        <dt>
            <h1 className="heading">Projects:</h1><br/>
        </dt>
        <dd>
            <p><b>News fetch:</b> This application will help you to get news information by a api you can use any api
                from this api you have to collect the information this application you can deploy for free in github or
                in the other service if you want to know about how to deploy in github then click this <a
                    className="text-primary" href="blog1.html">Link</a>.</p><br/>
                    <p><b>Css Framework:</b> This framework will help you to make website very quickly and very nice design like bootstrap or tailwind css.</p><br/>
            <p><b>Notes taking website:</b> This application will help you to take notes you can make this project for
                your web development skills to test and this application will help you a lot. See the design below for website design idea.</p><br/>
           <img src="https://theblog.co.in/media/Notes Taking App.png" alt="image" className="image_size"/>
                <p><b>Rock paper sccisor game: </b> This game is very popular and if you make this game and send to your friend they will be very very happy 😎. See the design below for website design.</p><br/>
                <img src="https://theblog.co.in/media/Rock Paper Sccisor.png" alt="images" className="image_size"/>
                <p><b>Clock:</b> In this project you can make anyone or both of them you can make analog or digital clock this help you a lot to see the time.</p><br/>
                <div style={{display:"flex"}}>
                    <img src="https://theblog.co.in/media/Clock.png" className="image_size2" alt="clock"/>
                    <img src="https://theblog.co.in/media/Analog clock.png" className="image_size2" alt="clock"/>
                </div>
            <p><b>Reminder:</b> This application will remind you when the time is right then it will ring a sound it's similar to an alarm but if you are a programmer a programmer forget things anytimes that is the truth. See the design below for website design you can notice that a new feature I have added that is dark mode and light mode.</p><br/>
            <img src="https://theblog.co.in/media/Reminder.png" className="image_size" alt="Reminder"/>
            <p><b>TextUtils:</b>This application will help you to count number of words and letters and you can add extra features like word without space or count the space in the paragraph. See the design below for website design.</p><br/>
            <img src="https://theblog.co.in/media/TextUtils.png" className="image_size" alt="TextUtils"/>
            <p><b>Text Finder:</b> This application will you to find the a word in a big paragraph and this will tell that number words found in the paragraph. See the design below for website design.</p><br/>
            <img src="https://theblog.co.in/media/TextFinder.png" className="image_size" alt="Text-Finder"/>
            <p><b>Login form:</b> This application will let the user enter the username and password and it should be a unique design. See the design below for website design.</p><br/>
            <img src="https://theblog.co.in/media/LoginForm.png" className="image_size" alt="Login-Form"/>
            <p><b>Profile:</b> You can make your own profile by designing it and you can show this project to your friends or your teachers etc. See the design below for website design.</p><br/>
            <img src="https://theblog.co.in/media/Profile.png" className="image_size" alt="Profile"/>
            <p><b>Go Green:</b> This application will show that plants and trees are very important to our earth and etc. See the design below for website design.</p>
            <img src="https://theblog.co.in/media/GoGreen.png" className="image_size" alt="Go-Green"/>
        </dd>
    </dl>
       </>
    )
}
