import React from 'react'
import "./style.css"
export default function Blog2() {
    let style1={
        fontSize:"25px",
        fontWeight:"bold"
    }
    document.title = `Blog - How to solve pip is not recognized as the internal and external command error`
    return (
        <>
        <h1 style={style1} className="text-center">How to solve pip is not recognized as the internal or external command error
        in python. Method1 (4 STEPS) and Method2 (7 STEPS)</h1>
    <br/><br/>
    <h1 style={style1} className="text-center">There is 2 methods to solve the error</h1>
    <br/><br/>
    <dl>
        <dt>
            <h1 style={style1}>Method1:</h1><br/>
        </dt>
        <dd>
            <p>1. Uninstall your python</p>
            <p>2. Install new version of python</p>
            <p>3. After downlaod click on the python there will be two checks add to path python and
                another option name Install laucher of all users check the two option and click intall</p>
            <img src="https://theblog.co.in/media/python%20install.png" className="image_size" alt="image"/>
            <p>4. After installing the python go to powershell or command prompt and type pip if it's telling some big
                content then your problem has been solved if it's showing error then please follow method 2</p>
            <img src="https://theblog.co.in/media/python%20pip.png" className="image_size" alt="image"/>
        </dd>
    </dl> <br/><br/>
    <dl>
        <dt>
            <h1 style={style1}>Method2:</h1><br/>
        </dt>
        <dd>
            <p>1. Go to python installed folder that folder will be default in
                C:\Users\ASUS\AppData\Local\Programs\Python\Python39</p>
            <img src="https://theblog.co.in/media/python%20folder.png" alt="image" className="image_size"/>
            <p>2. Copy the url and type in the search env and click on it</p>
            <img src="https://theblog.co.in/media/python%20env.png" alt="image" className="image_size"/>
            <p>3. Select environment variables</p>
            <img src="https://theblog.co.in/media/python%20env2.png" alt="image" className="image_size"/>
            <p>4. Select path and click edit</p>
            <img src="https://theblog.co.in/media/python%20env3.png" alt="image" className="image_size"/>
            <p>5. Click on new and paste your url in the the text field and click on ok</p>
            <img src="https://theblog.co.in/media/python%20env4.png" alt="image" className="image_size"/>
            <p>6. Go to script folder in python folder and copy the script folder url and paste on env same steps are
                there like you saw in earlier</p>
            <p>7. Open powershell or command prompt write pip it will show you some big content then your sucessfully
                added the python folder and script folder</p>
            <img src="https://theblog.co.in/media/python%20pip.png" className="image_size" alt="image"/>
        </dd>
    </dl>
        </>
    )
}
