import React from 'react'

export default function Blog5() {
    document.title = `Blog - About Repl teh online IDE`
    return (
        <>
             <h1 class="heading text-center">About repl the oneline IDE (8 STEPS)</h1><br/><br/>
    <h1 class="heading text-center">What is repl?</h1><br/><br/>
    <p>Repl is a online IDE if your computer is slow then you can use this repl. This IDE support many programming
        language like java, c, c++,python and web development etc. It's simple and easy to use it and it's free to use
        but there is some plan like hacker plan which you have to pay for it.
        Let's see how to use it
    </p><br/><br/>
    <dl>
        <dt>
            <h1 class="heading">Steps:</h1>
        </dt>
        <dd>
            <p>1. Open replit.com</p>
            <p>2. login into repl</p>
            <p>3. After login there will be a + button in the right side of the header click on it</p>
            <img src="https://theblog.co.in/media/repl + button.png" alt="image" class="image_size"/>
            <p>4. You will see a dialog box select the programming language and name your project and click create repl
            </p>
            <img src="https://theblog.co.in/media/repl dialog box.png" alt="image" class="image_size"/>
            <p>5. You will be some things that is shown in image. You can code now if you want to see the output in the
                repl only click on run button if you want to open this website output in new tab you can open this there
                is in the right side of the header</p>
            <img src="https://theblog.co.in/media/repl coding dashboard.png" alt="image" class="image_size"/>
            <p>6. If you want to make theme dark go to the setting in the tools there will be a option theme light will
                be default dark is your choice click on dark now you can see the dark theme</p>
            <img src="https://theblog.co.in/media/repl theme.png" alt="image" class="image_size"/>
            <p>7. If you want to upload file or create file or create a folder there is a icon in the left side as shown
                in image 3</p>
            <p>8. Go to the repl dashboard there will be a option my repls click it and you can see all your projects
                there and you can open any of the project that you want to open. You can create a folder</p>
            <img src="https://theblog.co.in/media/repl dashboard.png" alt="image" class="image_size"/>
        </dd>
    </dl>
        </>
    )
}
