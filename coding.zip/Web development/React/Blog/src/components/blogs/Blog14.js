import React from 'react'

export default function Blog14() {
    document.title = 'How to use Google Chorme as text editor'
    return (
        <>
         <h1 class="heading text-center">How to use Google Chorme as text editor (Steps 2)</h1><br/><br/>
    <dl>
        <dt>
            <h1 class="headings">Steps:</h1><br/>
        </dt>
        <dd>
            <p><b>1.</b> Open Google Chorme and type in url bar data:text/html,&lt;html contenteditable&gt; and press enter or go to this site <a target="_blank" href="https://muhammedraiyaan2.github.io/NotePad" class="a">Click this link</a></p>
            <p><b>2. </b> You can see the output like show in the image.</p>
            <img src="https://muhammedraiyaan2.github.io/Server/google as text editor.png" alt="google as text editor.png" class="image_size"/>
        </dd>
    </dl>
        </>
    )
}
