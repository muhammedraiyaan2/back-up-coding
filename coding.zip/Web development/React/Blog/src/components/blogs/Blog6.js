import React from 'react'

export default function Blog6() {
    document.title = `Blog - How to keep your code safe`
    return (
        <>
             <h1 className="heading text-center">How to keep your code safe (3 STEPS)</h1><br/><br/>
    <h1 className="heading text-center">How to do that</h1><br/><br/>
    <p>You can search obfuscator for the programming languages like JavaScript obfuscator, If anyone wants to see your source code of the website he/she can't understand because the code is obfuscated If you write alert hello world in javascript when you obfuscate it is totaly changed and anyone can't understand.</p>
<br/><br/>
    <dl>
        <dt>
            <h1 className="heading">Steps:</h1>
        </dt>
        <dd>
          <p>1. Go to any obfuscator website for the particular programming language example HTML obfuscator.</p>
          <img src="https://theblog.co.in/media/html obfuscator search.png" alt="image" className="image_size"/>
          <p>2. Open any good obfuscator website and paste your code in the text box.</p>
          <img src="https://theblog.co.in/media/obfuscator website.png" alt="image" className="image_size"/>
          <p>3. Paste the obfuscated code into your coding IDE.</p>
          <p><b>Note:</b> Please keep a backup of your not obfuscated code</p>
        </dd>
    </dl>
        </>
    )
}
