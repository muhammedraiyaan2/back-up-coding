import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
export default function Blog18() {
    let social={
        height:"100vh",
        width:"100%",
    }
    document.title = "Blog - Learn how to use visual studio code"
    return (
        <>
        <h1 class="heading text-center">Learn how to use Visual Studio Code </h1>
    <p class="description">If you have not installed Visual Studio Code go to <Link to="/how-to-install-visual-studio-code-blog16" class="a">this
            link</Link></p>
    <br/><br/>
    <dl>
        <dt>
        </dt>
        <dd>
            <p><b>1. Changing the theme:</b> If you want to change the theme go to settings and click on color theme and
                select your theme or press <br/> <kbd>Ctrl+k Ctrl+T</kbd></p>
            <video src="https://theblog.co.in/media/vs code how to change the theme.mp4" autoPlay="true" loop="true"
                class="image_size" muted></video>
            <p><b>2. Opening a folder:</b> If you want to open a folder then click on file and click on open folder or
                press <kbd>Ctrl+O</kbd></p>
            <video src="https://theblog.co.in/media/open a folder in  vs code - video.mp4" autoPlay="true" loop="true"
                muted class="image_size"></video>
            <p><b>3. Create a new file in a folder:</b> click on + button and name the file and your file will be
                created after writing some code press <kbd>Ctrl+S</kbd> to save the file</p>
            <video src="https://theblog.co.in/media/create a new file in vs code - video.mp4" autoPlay="true"
                muted loop="true" class="image_size"></video>
            <p><b>4. Extension:</b> extensions are used to make your IDE look better and help in many ways like theme,
                thunder client and Ssh remote etc. Go to extensions or presss <kbd>Ctrl+Shift+X</kbd> in your vs code
                and search some of extensions name. If you want to want more themes and the icon of the vs code files
                should be good then install this extension Material theme icon and Community Material theme. Material
                theme icon is used for making your file iocns look better and Community Material theme is used gives you
                many themes dark and light etc. After you install the extensions if the extension is not working please
                reopen your vs code.</p>
            <video src="https://theblog.co.in/media/Theme externsions for vs code - video.mp4" autoPlay="true"
                loop="true" muted class="image_size"></video>
            <p><b>5. Change keyboard shortcuts:</b> Click on setting and click on Keyboard Shortcuts or press
                <kbd>Ctrl+K Ctrl+S</kbd> and search what you want to change like I want to change the theme shortcut to
                <kbd>Alt+C</kbd> instead of <kbd>Ctrl+K Ctrl+T</kbd> search in keyboard shortcuts theme and click on the
                pencil icon this icon only appear when you hover on the shortcut. And press the key that you want to
                change the keyboard shortcut and press Enter.
            </p>
            <video
                src="https://theblog.co.in/media/change the keyboard shortcut of color theme - video.mp4"
                autoPlay="true" loop="true" muted class="image_size"></video>
            <p><b>6. Settings:</b> You can change the setting in the vs code you have to go in setting and click on
                setting or press <kbd>Ctrl+,</kbd> and search the setting and it will show you the setting. Like you can
                change the zoom of the vs code in mouse like <kbd>Ctrl+MouseWheel</kbd></p>
            <video src="https://theblog.co.in/media/change the setting in vs code - video.mp4" autoPlay="true"
                loop="true" muted class="image_size"></video>
            <p><b>7. Creating a folder:</b> To created folder follow the same method as you followed in how to create a
                new file in a opened folder. Now please select the folder button to create folder not file button in vs
                code expolorer.</p>
            <video src="https://theblog.co.in/media/how to create a folder in vs code - video.mp4"
                autoPlay="true" loop="true" muted class="image_size"></video>
        </dd>
    </dl>
    <br /><iframe style={social} src="https://theblog.co.in/iframe/learnhowtousevscode.html" frameborder="0"></iframe>
        </>
    )
}
