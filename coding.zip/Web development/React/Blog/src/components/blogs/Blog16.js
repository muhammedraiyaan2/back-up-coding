import React from 'react'

export default function Blog16() {
    document.title = "Blog - How to install visual studio code"
    return (
        <>
        <h1 class="heading text-center">How to install Visual Studio Code in Windows (Steps 8)</h1>
    <p class="description text-center"><b>About Visual Studio Code</b><br/>
    Visual Studio Code is made by Microsoft which is a IDE for all programming languages that can be C,C++,Java and HTMl. Visual Studio Code is launched on 2015, April 29. It can be run on Windows, Linux and Mac OS. Visual Studio Code is a very popular IDE which is used in many companies. Visual Studio Code as more extension <b>Ex:</b> Tabnine and Material Theme. Visual Studio Code has many themes. Visual Studio Code has custom snippets. Visual Studio Code has Git. Visual Studio Code you can call as vs code also.</p><br/><br/>
    <br/><br/>
    <dl>
        <dt>
            <h1 class="headings">Steps:</h1><br/>
        </dt>
        <dd>
           <p><b>1.</b> <a href="https://code.visualstudio.com/download" class="a">Open this to download vs code</a> and click the Windows button to download if you are in Linux then select Linux or Mac.</p>
           <img src="https://theblog.co.in/media/Download vs code options.png" alt="Download vs code options" class="image_size"/>
           <p><b>2.</b> As you can see the downloading.</p>
           <img src="https://theblog.co.in/media/vs code is started to download.png" alt="vs code is started to download" class="image_size"/>
           <p><b>3.</b> Open Download Folder in your computer and as you can see the visual studio code is installed.</p>
           <img src="https://theblog.co.in/media/open download folder vs code.png" alt="open download folder vs code" class="image_size"/>
           <p><b>4.</b> Click on the visual studio code icon to downlaod it in your computer and select I accept the agrement and click next button.</p>
           <img src="https://theblog.co.in/media/agrement in vs code.png" alt="agrement in vs code" class="image_size"/>
           <p><b>5.</b> Select the location where you want to intall vs code and click next button <b>Note:</b> Default location is always better to use.</p>
           <img src="https://theblog.co.in/media/vs code location to install.png" alt="vs code location to install" class="image_size"/>
           <p><b>6.</b> As you can see that it asking you to name vs code click next as default.</p>
           <img src="https://theblog.co.in/media/vs code name for start menu.png" alt="vs code name for start menu" class="image_size"/>
           <p><b>7.</b> There are some option select all of them this benifits you a lot <b>Ex:</b> You can right in a folder and there will be a option open with code if you click that the folder will be open in vs code. Click next button and the vs code will installed in your computer.</p>
           <img src="https://theblog.co.in/media/vs code checks boxs.png" alt="vs code checks boxs" class="image_size"/>
           <p><b>8.</b> After donwlaoding it will show you that lauch vs code and click finish and your vs code will lauch or you can type in search box vs code. And here is your vs code</p>
           <img src="https://theblog.co.in/media/setup finished lauch vs code now.png" alt="setup finished lauch vs code now" class="image_size"/><br/>
           <img src="https://theblog.co.in/media/vs code preview.png" alt="vs code preview" class="image_size"/>
        </dd>
    </dl>
        </>
    )
}
