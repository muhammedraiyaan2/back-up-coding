import React from 'react'

export default function Blog12() {
    document.title = 'Blog - Top 5 programming languages'
    return (
        <>
        <h1 class="heading text-center">Top 5 Programming Languages</h1><br/><br/>
    <h2 class="description"><b>Note:</b> This blog is not sponsored by any company this shows you the detail why the
        programming languages is in the top list. Every programming languages has a specific feature that you can't see
        in other programming languages <b>ex:</b> C language has pointer.</h2>
    <br/><br/>
    <dl>
        <dt>
            <h1 class="headings">Programming Languages:</h1><br/>
        </dt>
        <dd>
            <p><b>1. Python</b> is a very popular programming language and the most demanded programming language with
                python you can make Game, GUI, Website backend with Django or Flask , Scripting, Software, AI and
                Database.</p>
            <p><b>2. JavaScript</b> is the second most popular programming language for web development fronted and
                backend and the second most demanded programming language with JavaScript you can make Website Backend
                and Frontend and Scripting.</p>
            <p><b>3. Java</b> is the third most popular programming language for Backend and the third most demand
                programming language with Java you can make GUI, Scripting, Software, Website Backend with Spring Boot
                and Android Development.</p>
            <p><b>4. C and C++</b> This two Programming Languages is know as mother of all Programming Languages. This
                two Programming Languages is very fast compared to Python or Java. So it's near to hardware and c and
                c++ used in developing game like GTA for pc and GTA runs very fast.</p>
            <p><b>5. Dart</b> is a very modern and popular programming language and the demanded of this language is
                increasing day by day. Dart is developed by google</p>
        </dd>
    </dl>
        </>
    )
}
