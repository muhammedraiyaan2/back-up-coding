import React from 'react'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
export default function Blog3() {
    document.title = `Blog - How to convert .py to .exe`
    return (
        <>
            <h1 className="heading text-center">How to covert .py file to .exe (6 STEPS)</h1><br/><br/>
    <dl>
        <dt>
            <h1 className="heading">Steps:</h1>
        </dt><br/>
        <dd>
            <p>1. Open powershell or command prompt</p>
            <p>2. Write pip install pyinstaller in terminal and press enter then you can use pyinstaller if it's showing
                pip is not recognized as the internal or the external command then go to this <Link className="a"
                to="/pip-is-not-recognized-blog2">Link</Link></p>
            <img src="https://theblog.co.in/media/pip%20install%20pyinstaller.png" alt="image" className="image_size"/>
            <p>3. Open the folder where you want to convert the file After opening the folder type in the address bar powershell or cmd and press enter and you can able to open terminal in the folder
            <img src="https://theblog.co.in/media/url%20address%20bar.png" alt="image" className="image_size"/>
            <p>4. Write pyinstaller --onefile file_name and press enter. After writing pyinstaller --onefile write your file name as .\file_name a shortcut for this is you have to write first 4 letter of the file name and press tab and the terminal will auto correct it</p>
            <img src="https://theblog.co.in/media/pyinstaller%20--onefile%20file_name.png" alt="image" className="image_size"/>
            <p>5. After some seconds the exe file is ready. There will created some folder like build and dist etc. Go to dist folder and there you can get your exe</p>
            <img src="https://theblog.co.in/media/ready%20exe.png" className="image_size" alt="image"/>
            <p>6. When you run this program it will exit file automatically You can solve this by one solution that is in the .py file of the project you have to add a blank input in python and you have to save it. Uninstall the program in the dist folder and open terminal again and follow the same steps that you have follwed before</p>
            </p>
        </dd>
    </dl>
        </>
    )
}
