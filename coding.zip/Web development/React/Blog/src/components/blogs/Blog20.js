import React from 'react'

export default function Blog20() {
    let social={
        height:"100vh",
        width:"100%"
    }
    document.title = "Blog - React vs Angular"
    return (
        <>
        <h1 class="heading text-center">React vs Angular</h1>
    <p class="description"><b>Note:</b> This blog is not sponsored. This blog shows you the logic why React or Angular is better to use and a suggestion.</p>
    <br/><br/>
    <dl>
        <dt>
        </dt>
        <dd>
            <p><b>1. React: </b> is a most popular single page application framework, react is a JavaScript framework whereas Angular is TypeScript framework. Most programmers knows JavaScript and few programmers know TypeScript, So most people use React. React is developed by FaceBook. React have many backend components like React MERN (MongoDB, Express, React and Node Js). React have a component React Router Dom which help you to move a one page to other page without reload the page.</p><br/>
            <p><b>2. Angular: </b> is a popular single page application framework developed by Google which is a TypeScript framework. Angular have a other version Angular Js which are stoped using in many industries and started to use Angular because it's easy to use compared to Angular Js.</p><br/>
            <p><b>Conclusion: </b> React is better to use for beginners because React is a JavaScript framework and many programmers know JavaScript whereas Angular is a TypeScript framework and a few programmers know TypeScript. If you know JavaScript and TypeScript then you can use any one of them.</p><br/>
            <br /><p style={{color: 'red'}}>If you like the blog please like the blog or if you think something is wrong you can comment below we see all your comments. Comment below which is your favourite Single Page Application framework.</p><br/>
        </dd>
    </dl><br/>
    <br /><iframe style={social} src="https://theblog.co.in/iframe/reactvsangular.html" frameborder="0"></iframe>
        </>
    )
}
