import React from 'react'

export default function Blog15() {
    return (
       <>
        <h1 class="heading text-center">How to type in other languages in windows 10 (Steps 11)</h1><br/><br/>
    <dl>
        <dt>
            <h1 class="headings">Steps:</h1><br/>
        </dt>
        <dd>
            <p><b>1.</b> Open settings</p>
            <img src="https://theblog.co.in/media/open settings.png" alt="open settings" class="image_size"/>
            <p><b>2.</b> Click on time and languages settings</p>
            <img src="https://theblog.co.in/media/time and languages setting.png" alt="time & languages setting" class="image_size"/>
            <p><b>3.</b> Click on Language</p>
            <img src="https://theblog.co.in/media/Languages setting.png" alt="language setting" class="image_size"/>
            <p><b>4.</b> Click on add a language</p>
            <img src="https://theblog.co.in/media/add keyboard typing languages.png" alt="add keyboard typing languages" class="image_size"/>
            <p><b>5.</b> Select your language that you want to type in your computer and click next button</p>
            <img src="https://theblog.co.in/media/select your language setting.png" alt="select your language setting" class="image_size"/>
            <p><b>6.</b> Click on install button and the language will be installed</p>
            <img src="https://theblog.co.in/media/language install.png" alt="language install" class="image_size"/>
            <p><b>7.</b> As you can see that the language is installed</p>
            <img src="https://theblog.co.in/media/the language is installed.png" alt="the language installed" class="image_size"/>
            <p><b>8.</b> Click on ENG button on your right side of taskbar or press <kbd>Windows+Space</kbd></p>
            <img src="https://theblog.co.in/media/ENG button.png" alt="ENG button" class="image_size"/>
            <p><b>9.</b> Select your language and start typing</p>
            <img src="https://theblog.co.in/media/select your language and start typinh.png" alt="select your language and start typing" class="image_size"/>
            <img src="https://theblog.co.in/media/typing in a new language.png" alt="typing in a new language" class="image_size"/>
            <p><b>10.</b> If you want to type in english then press Windows+Space and select english</p>
            <p><b>11.</b> If you want to delete a language then go to settings and click on the language and select remove button</p>
            <img src="https://theblog.co.in/media/languages remove button.png" alt="languages remove button" class="image_size"/>
        </dd>
    </dl>
       </>
    )
}
