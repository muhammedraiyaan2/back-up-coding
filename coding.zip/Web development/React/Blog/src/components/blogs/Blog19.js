import React from 'react'

export default function Blog19() {
    document.title = `Blog - 7 Web Development tools`
    let social={
        width:"100%",
        height:"100vh",
        overflow:"hidden",
    }
    return (
        <>
    <h1 className="heading text-center">7 Web Development tools </h1>
    <p className="description"><b>Note:</b> This blog is not sponsored by any company</p>
    <br/>
    <dl>
        <dt>
            <h1 className="headings">Tools:</h1><br/>
        </dt>
        <dd>
            <p><b>1. Hd Images and Videos:</b> Many websites want hd images and videos and
                <a target="_blank" href="https://pexels.com" className="a">pexels.com</a> offers you hd and 4k images and
                videos and allow you to downlaod the images or videos. Go to <a target="_blank"
                    href="https://pexels.com" className="a">pexels.com</a> and search the image or video name default is
                image if you want videos and click on videos.
            </p>
            <video src="https://theblog.co.in/media/how%20to%20use%20pexels.com%20-%20video.mp4" autoplay="true" loop muted
                className="image_size"></video>
            <p><b>2. Icons:</b> There is no website without a social media icons or any other icons and <a
                    href="https://feathericons.com" target="_blank" className="a">feathericons.com</a> allows you to get
                many icons with different colors and size you can search in feathericons.com what the icon you want and
                click on icon and it will download. There is a option of light mode and dark mode you can select up to
                your choice.</p>
            <video src="https://theblog.co.in/media/how%20to%20use%20feathericons.com%20-%20video.mp4" autoplay="true" loop
                muted className="image_size"></video>
            <p><b>3. Image and Video Compressor:</b> Some website want to display images or videos but the problem is
                the image or video size is very large and it's taking time to display the images or videos so you can
                compress them and <a href="https://freeconvert.com/image-compressor" target="_blank"
                    className="a">freeconvert.com/imageOrVideo-compressor</a> allows you to compress your image and you can
                download the compressed images or videos.</p>
            <video src="https://muhammedraiyaan2.github.io/Server/how to use freeconvert.com.mp4" autoplay="true" loop muted
                className="image_size"></video>
            <p><b>4. Convert the extension of a media:</b> Some times a .avi file is not supported so you have to change
                it to .mp4 or with images some times png is not supported and you have to change it to jpg and <a
                    href="https://freeconvert.com" target="_blank" className="a">freeconvert.com</a> allows you to conver
                the file extension that can be a image, video, music, documents and archives.</p>
            <video src="https://theblog.co.in/media/how%20to%20use%20freeconvert.com.mp4"
                autoplay="true" loop muted className="image_size"></video>
            <p><b>5. JSON Placeholder:</b> Some times you want to test a xml program or you have test a JSON from the
                internet and <a href="https://jsonplaceholder.typicode.com" target="_blank"
                    className="a">jsonplaceholder.typicode.com</a> allows you to test the json api with GET request and POST
                request.</p>
            <video src="https://theblog.co.in/media/how%20to%20use%20jsonplaceholder.com.mp4" autoplay="true" loop
                muted className="image_size"></video>
            <p><b>6. JSON formatter:</b> Some times the JSON is not formatted and you can't understand it so JSON
                formatter is free chorme extension that help you to format your JSON code. <a
                    href="https://chrome.google.com/webstore/detail/json-formatter/mhimpmpmffogbmmkmajibklelopddmjf/related"
                    target="_blank" className="a">Click this link to download JSON formatter.</a></p>
            <video src="https://theblog.co.in/media/how%20to%20use%20JSON%20formatter%20-%20video.mp4" autoplay="true" loop
                muted className="image_size"></video>
            <p><b>7. OneTab:</b> Some times your computer started hang of chorme you can use ontab free chorme extension
                that bring all your tabs to one tab.Details are explain in video. <a
                    href="https://chrome.google.com/webstore/detail/onetab/chphlpgkkbolifaimnlloiipkdnihall"
                    target="_blank" className="a">Click this link to install onetab.</a></p>
            <video src="https://theblog.co.in/media/how%20to%20use%20onetab%20-%20video.mp4" autoplay="true" loop muted
                className="image_size"></video>
            <br /><p style={{color: 'red'}}> Comment down below which is the best tool in your opinion. If you like the blog please like the blog
                below if you think some things are not explained well please comment below I see all your comments.</p>
        </dd>
    </dl><br/>
    <br /><iframe style={social} src="https://theblog.co.in/5webdevelopmenttools.html" frameborder="0"></iframe>
        </>
    )
}
