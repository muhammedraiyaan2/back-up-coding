import React from 'react'
import './style.css'
export default function Blog17() {
    let social={
        width:"100%",
        height:"100vh",
        overflow:"hidden",
    }
    document.title = `Blog - What is lighthouse how to use lighthouse`
    return (
        <>
            
            <h1 className="heading text-center">What is light house and how to use light house in chorme (Steps 4)</h1>
    <p className="description text-center"><b>About Light House in Chomre</b><br/>
        Light House generates a report of a website like SEO, Performance and Acessibility etc. It tell you the score of
        the website and it will tell about how you can improve your website. <b>Note:</b> This works only in google
        chorme.</p><br/><br/>
    <br/><br/>
    <dl>
        <dt>
            <h1 className="headings">Steps:</h1><br/>
        </dt>
        <dd>
            <p><b>1.</b> Open any website and right and click on inspect or press <kbd
                    title="Ctrl+Shift+I">Ctrl+Shift+I</kbd></p>
            <img src="https://theblog.co.in/media/Screenshot%20(522).png" alt="Select inspect"
                className="image_size"/>
            <p><b>2.</b> Go to Light House Option</p>
            <img src="https://theblog.co.in/media/Screenshot%20(523).png" alt="Click on light house"
                className="image_size" />
            <p><b>3.</b> Now see your light house there are many option there are categories and device etc. If you want
                to know the report of the website in phone then select phone or in desktop select desktop. There some
                option in categories like SEO, Performance abd Acessibility etc select all of them and click generate
                report. When you click on generate report it will load for sometime</p>
            <img src="https://theblog.co.in/media/Screenshot%20(524).png" alt="Select the options"
                className="image_size" />
            <p><b>4.</b> As you can see that the report is finished and you can see the score of the website. If you
                scroll down then it will tell the how to improve your site.</p>
            <img src="https://theblog.co.in/media/Screenshot%20(525).png" alt="Report" className="image_size"/>
            <p><b>External:</b> You can see the video how to generate light house report.</p>
            <video src="https://theblog.co.in/media/bandicam%202021-10-27%2018-03-18-619.mp4" muted="true"
                autoplay="true" loop className="image_size"></video>
        </dd>
    </dl>
        </>
    )
}
