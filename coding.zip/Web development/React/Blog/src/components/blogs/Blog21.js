import React from 'react'
import "./style.css"
export default function Blog21() {
    document.title = '5 Useful Google Chorme Extensions'
    return (
        <>
            <h1 class="heading text-center">5 Useful Google Chorme Extensions</h1>
            <p class="description"><b>Note:</b> This blog is not sponsored</p>
            <br/>
            <p><b>1. Project Naptha</b> is a free chorme extension that help you to copy the text in the image for example your search a riddle and you select a image you can copy the text in the image with the project naptha extension. <a className="text-primary" href="https://chrome.google.com/webstore/detail/project-naptha/molncoemjfmpgdkbdlbjmhlcgniigdnf" target="_blank">Click here to open project naptha</a> </p>
            <video src="https://theblog.co.in/media/How%20to%20use%20project%20naptha%20extension.mp4" autoPlay="true" className="image_size" loop="true"></video>
            <p><b>2. OneTab</b> is a free and extension that helps you to bring all the chorme tab in a single tab. <a href="https://chrome.google.com/webstore/detail/onetab/chphlpgkkbolifaimnlloiipkdnihall?hl=en" className="text-primary" target="_blank">Click here to open onetab</a> </p>
            <video src="https://theblog.co.in/media/how%20to%20use%20onetab%20-%20video.mp4" autoPlay="true" className="image_size" loop="true"></video>
            <p><b>3. Todoist</b> is free chorme extension that help you to manage your task in chomre. <a href="https://chrome.google.com/webstore/detail/todoist-for-chrome/jldhpllghnbhlbpcmnajkpdmadaolakh/related?hl=en" target="_blank" className="text-primary" target="_blank">Click here to open Todoist</a> </p>
            <video src="https://theblog.co.in/media/How to use Todoist.mp4" autoPlay="true" className="image_size" loop="true"></video>
            <p><b>4. What Font</b> is free chorme extension that help you to see the what font is there in a website. <a href="https://chrome.google.com/webstore/detail/whatfont/jabopobgcpjmedljpbcaablpmlmfcogm?hl=en" className="text-primary" target="_blank">Click here to open What Font</a> </p>
            <video src="https://theblog.co.in/media/how to use what font.mp4" autoPlay="true" className="image_size" loop="true"></video>
            <p><b>5. LightHouse</b> is a free chorme extension that helps you to check the score of any site that can be yours also. <a href="https://chrome.google.com/webstore/detail/lighthouse/blipmdconlkpinefehnmjammfjpmpbjk?hl=en" className="text-primary" target="_blank">Click here to open LightHouse extension</a></p>
            <video src="https://theblog.co.in/media/how to use lighthouse extension.mp4" autoPlay="true" className="image_size" loop="true"></video>
            <br /><p style={{color: 'red'}}>If you like the article, you can like the article by clicking the below like button, if you think that this article is not good some improvements have to made then comment below we see all your comments and listen to you peoples.</p>
            <br /><iframe className="social" src="https://theblog.co.in/iframe/5usefulchormeextensions.html" frameborder="0"></iframe>
        </>
    )
}
