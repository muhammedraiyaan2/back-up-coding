import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar'
import Home from './components/Home'
import Footer from './components/Footer'
import About from './components/About'
import Contact from './components/Contact'
import Login from './components/Login'
// Blogs
import CheatSheetBlogList from './components/CheatSheetBlogList'
import PythonBlogList from './components/PythonBlogList'
import CommonBlogList from './components/CommonBlogList'
import ProgrammingCommonBlogList from './components/ProgrammingCommonBlogList'
import WebDevelopmentBlogList from './components/WebDevelopmentBlogList'
import Blog25 from './components/blogs/Blog25'
import Blog24 from './components/blogs/Blog24'
import Blog23 from './components/blogs/Blog23'
import Blog22 from './components/blogs/Blog22'
import Blog21 from './components/blogs/Blog21'
import Blog20 from './components/blogs/Blog20'
import Blog19 from './components/blogs/Blog19'
import Blog18 from './components/blogs/Blog18'
import Blog17 from './components/blogs/Blog17'
import Blog16 from './components/blogs/Blog16'
import Blog15 from './components/blogs/Blog15'
import Blog14 from './components/blogs/Blog14'
import Blog13 from './components/blogs/Blog13'
import Blog12 from './components/blogs/Blog12'
import Blog11 from './components/blogs/Blog11'
import Blog10 from './components/blogs/Blog10'
import Blog9 from './components/blogs/Blog9'
import Blog8 from './components/blogs/Blog8'
import Blog7 from './components/blogs/Blog7'
import Blog6 from './components/blogs/Blog6'
import Blog5 from './components/blogs/Blog5'
import Blog4 from './components/blogs/Blog4'
import Blog3 from './components/blogs/Blog3'
import Blog2 from './components/blogs/Blog2'
import Blog1 from './components/blogs/Blog1'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
function App() {
  return (
    <>
      <Router>
        <Navbar /><br /><br /><br />
        <Switch>
          <Route path="/the-best-web-hosting-platform-blog25" component={Blog25}></Route>
          <Route path="/how-to-turn-on-hotspot-in-laptop-blog24" component={Blog24}></Route>
          <Route path="/HTML-cheatsheet-blog23" component={Blog23}></Route>
          <Route path="/what-is-seo-how-to-improve-seo-blog22" component={Blog22}></Route>
          <Route path="/top-5-google-chorme-extensions-blog21" component={Blog21}></Route>
          <Route path="/react-vs-angular-blog20" component={Blog20} />
          <Route path="/7-web-development-tools-blog19" component={Blog19} />
          <Route path="/learn-how-to-use-visual-studio-code-blog18" component={Blog18} />
          <Route path="/what-is-lighthouse-how-to-use-lighthouse-blog17" component={Blog17} />
          <Route path="/how-to-install-visual-studio-code-blog16" component={Blog16} />
          <Route path="/how-to-type-in-other-language-in-windows-10-blog15" component={Blog15} />
          <Route path="/how-to-use-google-chomre-as-text-editor-blog14" component={Blog14} />
          <Route path="/top3-web-frameworks-blog13" component={Blog13} />
          <Route path="/top5-programmming-languages-blog12" component={Blog12} />
          <Route path="/5-python-projects-blog11" component={Blog11} />
          <Route path="/15-google-chorme-shortcuts-blog10" component={Blog10} />
          <Route path="/15-keyboard-shortcut-for-windows-blog9" component={Blog9} />
          <Route path="/11-web-development-projects-blog8" component={Blog8} />
          <Route path="/command-prompt-cool-tricks-blog7" component={Blog7} />
          <Route path="/how-to-keep-your-code-safe-blog6" component={Blog6} />
          <Route path="/about-repl-the-online-ide-blog5" component={Blog5} />
          <Route path="/how-to-make-a-http-server-blog4" component={Blog4} />
          <Route path="/how-to-convert-py-file-to-exe-file" component={Blog3} />
          <Route path="/pip-is-not-recognized-blog2" component={Blog2} />
          <Route path="/how-to-deploy-a-website-github-blog1" component={Blog1} />
          <Route path="/web-develoment-bloglist" component={WebDevelopmentBlogList} />
          <Route path="/programming-common-bloglist" component={ProgrammingCommonBlogList} />
          <Route path="/cheatsheet-bloglist" component={CheatSheetBlogList} />
          <Route path="/common-bloglist" component={CommonBlogList} />
          <Route path="/python-bloglist" component={PythonBlogList} />
          <Route path="/login" component={Login} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route component={Home} />
        </Switch>
        <Footer />
      </Router>
    </>
  );
}

export default App;
