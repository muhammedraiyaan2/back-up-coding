import javax.swing.*;
import java.awt.*;
public class sampleGui{
    public static void main(String[] args) {
        JFrame Frame = new JFrame();
        JButton Button = new JButton("Click Me");
        JLabel Label = new JLabel(" This is a Label");
        Label.setVerticalAlignment(JLabel.TOP);
        JPanel Panel = new JPanel();
        Image icon = Toolkit.getDefaultToolkit().getImage("D:\\coding\\backuped coding\\Web development\\Blog\\public\\icon.png");
        Panel.setBorder(BorderFactory.createEmptyBorder(600,0,0,1190));
        Panel.setLayout(new GridLayout(0,1));
        Button.setSize(10,10);
        Panel.add(Label);
//        Panel.add(Button);
        Frame.add(Panel,BorderLayout.CENTER);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Frame.setTitle("Masha Allah This is my first GUI in java");
        Frame.setIconImage(icon);
        Frame.pack();
        Frame.setVisible(true);
    }
}