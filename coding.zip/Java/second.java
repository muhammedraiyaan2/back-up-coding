public class second {
    public static void def(){
        System.out.println("This is my first def functin joking");
    }
    public static void main(String[] args) {
        System.out.println("This is file number 2"+1);
        def();
    }
}
