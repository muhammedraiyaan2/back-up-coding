package Vscode;
public class First{
    public static void main(String args[]){ 
        System.out.println("Masha Allah"); 
        System.out.println("Masha Allah");
        System.out.println("Masha Allah");
    } 
}
