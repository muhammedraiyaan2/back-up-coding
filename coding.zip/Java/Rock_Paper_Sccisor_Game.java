package Vscode;
import java.util.Scanner;
import java.util.Random;
public class Rock_Paper_Sccisor_Game {
    Random ran=new Random();
    int rand=ran.nextInt(3);
}
