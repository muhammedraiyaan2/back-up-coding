import java.util.Scanner;
public class sample {
    public static void main(String[] args) {
        System.out.print("Enter the number: ");
        Scanner scanner = new Scanner(System.in);
        long scanner2=scanner.nextInt();
        System.out.println(scanner2);
    }
}
