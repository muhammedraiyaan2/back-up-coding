package Vscode;

import java.util.Calendar;
public class milisecond_trial {
    public static void main(String[] args) {
        System.out.println(System.currentTimeMillis());
        Calendar rightNow=Calendar.getInstance();
        int hour=rightNow.get(Calendar.HOUR);
        System.out.println(hour);
    }
}
