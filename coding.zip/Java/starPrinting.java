public class starPrinting {
    public static void main(String[] args) {
        for (int a=0; a<6; a++){
            for(int b=5; b>a-1; b--){
                System.out.print("*");
            }
            System.out.println("");
        }
    }
}
