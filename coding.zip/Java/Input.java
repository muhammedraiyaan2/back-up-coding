import java.util.Scanner;

public class Input {
    public static void main(String[] args) {
        System.out.print("Enter the number: ");
        Scanner inpu=new Scanner(System.in);
        int n=inpu.nextInt();
        int d,sum=0;
        while (n!=0){
            d=n%10;
            sum=sum+d;
            n=n/10;
        }
        System.out.println(sum);
    }
}










