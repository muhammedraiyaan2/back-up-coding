package Vscode;

public class testing {
    public static void main(String[] args) {
        for(int i=0; i<5; i++){
            System.out.println("Masha Allah");
        }
        int i2=0;
        while(i2<5){
            System.out.println("Masha Allah");
            i2++;
        }
        int i3=0;
        do{
          i3++;
            System.out.println("Masha Allah");
        }while(i3<10);
    }
}
