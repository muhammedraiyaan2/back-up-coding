#include <iostream>
using namespace std;
int main() {
    int a,b,c;
    cout << "Enter the first number: ";
    cin>>a;
    cout<<"Enter the second number: ";
    cin>>b;
    cout<<"The sum is "<<a+b;
    cin>>c;
}
