    cout<<"Enter the second number: ";
