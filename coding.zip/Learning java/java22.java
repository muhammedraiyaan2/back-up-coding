public class java22 {
    public static void main(String[] args) {
        System.out.println("Testing!");
    }
}