class EkClass{
    int a;
    EkClass(int a){
        this.a=a;
   }

    public int getA() {
        return a;
    }

    public int return1(){
        return 1;
    }
}
public class java27 {
    public static void main(String[] args) {
        EkClass e=new EkClass(12);
        System.out.println(e.getA());
    }
}
