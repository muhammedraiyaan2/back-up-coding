class Phone{
    public void showTime(){
        System.out.println("The time is 8 am");
    }
    public void on(){
        System.out.println("Turing on Phone...");
    }
}
class SmartPhone extends Phone{
    public void music() {
        System.out.println("Playing music...");
    }
    public void on() {
        System.out.println("Turning on Smart Phone...");
    }
}
public class java29 {
    public static void main(String[] args) {
//        Phone obj=new Phone();  // Allowed
//        SmartPhone smobj=new SmartPhone();  // Allowed
//        obj.greet();
          Phone newObj=new SmartPhone(); // Allowed
//          SmartPhone obj2=new Phone(); // Not allowed
        newObj.showTime();
        newObj.on();
        // newObj.music(); // Not Allowed
    }
}
