interface Camera{
    void takeSnap();
    void recordVideo();
}
interface Wifi{
    String[] =getNetworks();
    void connecToNetwork(String network);
}
class SmartPhone1{
    void callNumber(){
        System.out.println("Calling...");
    }
    void takeSnap(){
        System.out.println("Taking Photo...");
    }
}
public class java33 {
    public static void main(String[] args) {

    }
}
