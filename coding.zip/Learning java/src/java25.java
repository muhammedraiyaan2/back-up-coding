// Inheritance means a previous class you are using in a new class
class Base{
    public int x;

    public int getX() {
        return x;
    }

    public void setX(int xs) {
        System.out.println("I am in base and setting x now");
        x = xs;
    }

    public static void printMe(){
        System.out.println("I am a constructor");
    }
}
class Derived extends Base{
    int y;

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
public class java25 {
    public static void main(String[] args) {
    //  Creating a class object Base
    Base b=new Base();
    b.setX(4);
    System.out.println(b.getX());
    // Creating a class object Derived
    Derived s=new Derived();
    s.setY(23);
    System.out.println(s.getY());
    }
}
