class Emoplyee2{
    private int id;
    private String name;
    public void setName(String n){
        name=n;
    }
    public String getName(){
        return name;
    }
    public void setId(int ids){
        id=ids;
    }
    public int getId(){
        return id;
    }
}
public class java24 {
    public static void main(String[] args) {
    Emoplyee2 Raiyaan=new Emoplyee2();
    Raiyaan.setName("Muhammad Raiyaan");
    Raiyaan.setId(72);
    System.out.print(Raiyaan.getName());
    System.out.print(" ");
    System.out.println(Raiyaan.getId());
    }
}
