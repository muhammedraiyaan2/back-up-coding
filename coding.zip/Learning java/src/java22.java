class Empolyee{
    int id;
    String name;
    void details(){
        System.out.print("Your id is "+id);
        System.out.println(" and your name is "+name);
    }

}
public class java22 {
    public static void main(String[] args) {
        System.out.println("This is java class 22 Creating our own class");
        Empolyee Raiyaan = new Empolyee();
//        Setting propertypes
        Raiyaan.id=85;
        Raiyaan.name = "Muhammad Raiyaan I";
        System.out.println(Raiyaan.id+" "+Raiyaan.name);
        Raiyaan.details();
    }
}
