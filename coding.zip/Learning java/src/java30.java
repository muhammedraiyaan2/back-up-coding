abstract class Parent2{
    public Parent2() {
        System.out.println("I am Base constructor");
    }
    void sayHello(){
        System.out.println("Hello");
    }
    abstract void greet();
    abstract void greet2();
}
class Child2 extends Parent2{
    @Override
    void greet(){
        System.out.println("Good morning");
    }
    @Override
    void greet2(){
        System.out.println("Good After Noon");
    }
}
abstract class Child3 extends Parent2{
    void good(){
        System.out.println("I am good");
    }
}
public class java30 {
    public static void main(String[] args) {
        Child2 child=new Child2();
        child.sayHello();
    }
}
