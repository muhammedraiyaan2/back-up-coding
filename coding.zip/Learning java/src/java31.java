interface Bicycle {
    final int a=12;
    void applyBreak(int decrements);

    void speedUp(int increment);
}

class AvonBicycle implements Bicycle {
    public void applyBreak(int decrements) {
        System.out.println("Applying break at "+decrements);
    }

    public void speedUp(int increment) {
        System.out.println("Increasing speed");
    }

    public static void horn() {
        System.out.println("Pe Pe Pe Po Po...");
    }
}

public class java31 {
    public static void main(String[] args) {
        AvonBicycle cyclse = new AvonBicycle();
        cyclse.applyBreak(2);
    }
}
