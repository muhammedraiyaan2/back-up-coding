class Emoplyee1{
    int salary;
    String name;
    public int getSalary(){
        return salary;
    }
    public String getName(){
        if(name==null){
            name="None";
        }
        return name;
    }
    public void setName(String names){
        name=names;
    }
    public void setSalary(int sal){
        salary=sal;
    }
}
class cellPhone{
    public void ring(){
        System.out.println("Ringing...");
    }
    public void vibrate(){
        System.out.println("Vibrating...");
    }
    public void call(String caller){
        System.out.println("Calling "+caller+"...");
    }
}
public class java23 {
    public static void main(String[] args) {
        // Problem 1
        Emoplyee1 Emo=new Emoplyee1();
        Emo.setName("Muhammad Raiyaan");
        Emo.setSalary(100000);
        // System.out.println("Your name is "+Emo.getName()+" Your Salary is "+Emo.getSalary());
        // Problem 2
        cellPhone phone1=new cellPhone();
        phone1.call("Yusha");
        phone1.vibrate();
        phone1.ring();
    }
}
